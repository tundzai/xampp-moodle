<?php
// File này giúp bạn tạo hash password bcrypt
// Sử dụng: Truy cập http://localhost/learning_teaching/helper/hash_generator.php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    $password = $_POST['password'];
    $hash = password_hash($password, PASSWORD_BCRYPT);
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Hash Generator</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container mt-5">
            <div class="alert alert-success">
                <h4>Mật khẩu gốc: <strong><?php echo htmlspecialchars($password); ?></strong></h4>
                <h5>Hash bcrypt:</h5>
                <code style="word-break: break-all; background: #f0f0f0; padding: 10px; display: block;">
                    <?php echo $hash; ?>
                </code>
                <button class="btn btn-primary mt-3" onclick="copyToClipboard()">Copy Hash</button>
            </div>
            <form method="POST">
                <input type="text" name="password" placeholder="Nhập mật khẩu mới" required class="form-control mb-2">
                <button type="submit" class="btn btn-primary">Tạo Hash</button>
            </form>
        </div>
        <script>
            function copyToClipboard() {
                const hash = document.querySelector('code').innerText;
                navigator.clipboard.writeText(hash).then(() => {
                    alert('Đã copy!');
                });
            }
        </script>
    </body>
    </html>
    <?php
} else {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Hash Generator</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container mt-5">
            <h3>Tạo Hash Password Bcrypt</h3>
            <form method="POST" class="mt-4">
                <div class="mb-3">
                    <label class="form-label">Nhập mật khẩu cần hash:</label>
                    <input type="text" name="password" placeholder="Ví dụ: admin123" required class="form-control">
                </div>
                <button type="submit" class="btn btn-primary">Tạo Hash</button>
            </form>
        </div>
    </body>
    </html>
    <?php
}
?>
