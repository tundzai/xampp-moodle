<?php

function XacMinhMatKhauSinhVien($sinhvien_mk, $conn, $masinhvien)
{
  $sql = "SELECT * FROM sinhvien
           WHERE masinhvien=?";
  $stmt = $conn->prepare($sql);
  $stmt->execute([$masinhvien]);

  if ($stmt->rowCount() == 1) {
    $sinhvien = $stmt->fetch();
    $pass  = $sinhvien['matkhau'];

    if (password_verify($sinhvien_mk, $pass)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    return 0;
  }
}

function XacMinhMatKhauGiangVien($giangvien_mk, $conn, $magiangvien)
{
  $sql = "SELECT * FROM giangvien
           WHERE magiangvien=?";
  $stmt = $conn->prepare($sql);
  $stmt->execute([$magiangvien]);

  if ($stmt->rowCount() == 1) {
    $giangvien = $stmt->fetch();
    $pass  = $giangvien['matkhau'];

    if (password_verify($giangvien_mk, $pass)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    return 0;
  }
}

function XacMinhMatKhauAdmin($admin_mk, $conn, $maadmin)
{
  $sql = "SELECT * FROM admin
           WHERE maadmin=?";
  $stmt = $conn->prepare($sql);
  $stmt->execute([$maadmin]);

  if ($stmt->rowCount() == 1) {
    $admin = $stmt->fetch();
    $pass  = $admin['matkhau'];

    if (password_verify($admin_mk, $pass)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    return 0;
  }
}
