<?php
if (isset($title)) {
	echo $title;
} else {
	echo "HUST - One Love One Future";
}
?>