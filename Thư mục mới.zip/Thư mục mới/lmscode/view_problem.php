<?php 
include 'config.php'; 

$id = isset($_GET['id']) ? intval($_GET['id']) : 1; // Mặc định lấy bài 1 nếu không có ID
$stmt = $conn->prepare("SELECT * FROM problems WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$problem = $stmt->get_result()->fetch_assoc();

if (!$problem) die("Bài tập không tồn tại!");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?php echo $problem['title']; ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; display: flex; height: 100vh; margin: 0; background: #f0f2f5; }
        .left-panel { width: 40%; padding: 20px; border-right: 2px solid #ddd; overflow-y: auto; background: #fcfcfc; }
        .right-panel { width: 60%; padding: 20px; display: flex; flex-direction: column; }
        #editor { flex-grow: 1; font-family: monospace; padding: 10px; background: #272822; color: white; font-size: 14px; min-height: 320px; }
        .btn-submit { padding: 15px; background: #007bff; color: white; border: none; cursor: pointer; font-size: 16px; }
        #resultArea { margin-top: 15px; padding: 10px; border: 1px solid #eee; background: #fff; min-height: 80px; }
        #warningBanner {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 9999;
            padding: 15px 20px;
            background: rgba(255, 60, 60, 0.95);
            color: #fff;
            font-size: 16px;
            text-align: center;
            display: none;
            box-shadow: 0 2px 10px rgba(0,0,0,.3);
        }
        #tabCountBanner {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 9998;
            padding: 15px 20px;
            background: rgba(0, 123, 255, 0.95);
            color: #fff;
            font-size: 16px;
            text-align: center;
            display: none;
            box-shadow: 0 2px 10px rgba(0,0,0,.3);
        }
    </style>
</head>
<body>
<div id="warningBanner">Bạn đã rời khỏi tab hoặc thoát khỏi chế độ toàn màn hình. Vui lòng quay lại ngay để tiếp tục làm bài.</div>
<div id="tabCountBanner">Bạn đã chuyển tab 0 lần.</div>

<div class="left-panel">
    <h1><?php echo $problem['title']; ?></h1>
    <hr>
    <div class="description">
        <?php echo $problem['description']; ?>
    </div>
    <p><strong>Ngôn ngữ yêu cầu:</strong> <?php echo strtoupper($problem['language_id']); ?></p>
</div>

<div class="right-panel">
    <h3>Trình soạn thảo</h3>
    <form id="submitForm" style="display: flex; flex-direction: column; flex-grow: 1;">
        <input type="hidden" name="problem_id" value="<?php echo $id; ?>">
        <textarea name="code" id="editor" placeholder="// Viết code của bạn tại đây..."></textarea>
        <button type="button" class="btn-submit" onclick="runTests()">Nộp bài (Submit)</button>
    </form>
    
    <div id="resultArea">
        <em>Kết quả chấm điểm sẽ hiện ở đây...</em>
    </div>
</div>

<script>
const warningBanner = document.getElementById('warningBanner');
const tabCountBanner = document.getElementById('tabCountBanner');
let fullScreenActive = false;
let tabSwitchCount = 0;

function showWarning(message) {
    if (!warningBanner) return;
    warningBanner.textContent = message;
    warningBanner.style.display = 'block';
}

function hideWarning() {
    if (!warningBanner) return;
    warningBanner.style.display = 'none';
}

function showTabCount(message) {
    if (!tabCountBanner) return;
    tabCountBanner.textContent = message;
    tabCountBanner.style.display = 'block';
}

function hideTabCount() {
    if (!tabCountBanner) return;
    tabCountBanner.style.display = 'none';
}

function requestExamFullscreen() {
    const element = document.documentElement;
    const tryRequest = element.requestFullscreen || element.webkitRequestFullscreen || element.mozRequestFullScreen || element.msRequestFullscreen;
    if (!tryRequest) return;
    try {
        const p = tryRequest.call(element);
        if (p && typeof p.then === 'function') {
            p.then(function() {
                fullScreenActive = true;
                hideWarning();
                hideTabCount();
            }).catch(function() {
                fullScreenActive = false;
                showWarning('Trình duyệt đã chặn chế độ toàn màn hình. Vui lòng bật tay bằng F11.');
            });
        } else {
            fullScreenActive = !!document.fullscreenElement;
            if (fullScreenActive) hideWarning();
        }
    } catch (e) {
        fullScreenActive = false;
        showWarning('Không thể vào chế độ toàn màn hình.');
    }
}

function isBrowserFullscreen() {
    try {
        // Some browsers set window.fullScreen, others change innerHeight to match screen height when F11 pressed
        if (typeof window.fullScreen !== 'undefined' && window.fullScreen) return true;
        var h = window.innerHeight || document.documentElement.clientHeight;
        var w = window.innerWidth || document.documentElement.clientWidth;
        // allow small tolerance for taskbars/menus
        var tol = 10;
        if (Math.abs(screen.height - h) <= tol || Math.abs(screen.width - w) <= tol) return true;
    } catch (e) {
        // ignore
    }
    return false;
}

function checkFullScreenState() {
    var browserFs = isBrowserFullscreen();
    var domFs = !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement);
    if (domFs || browserFs) {
        fullScreenActive = true;
        hideWarning();
        if (tabSwitchCount > 0) showTabCount('Bạn đã chuyển tab ' + tabSwitchCount + ' lần.');
    } else {
        fullScreenActive = false;
        hideTabCount();
        showWarning('Bạn đã thoát khỏi chế độ toàn màn hình. Vui lòng bật lại.');
    }
}

function handleVisibilityChange() {
    if (!fullScreenActive) return;
    if (document.hidden || document.visibilityState !== 'visible') {
        tabSwitchCount += 1;
        showTabCount('Bạn đã chuyển tab ' + tabSwitchCount + ' lần.');
    } else {
        if (tabSwitchCount > 0) showTabCount('Bạn đã chuyển tab ' + tabSwitchCount + ' lần.');
        else hideTabCount();
    }
}

window.addEventListener('DOMContentLoaded', function() {
    requestExamFullscreen();
    document.addEventListener('fullscreenchange', checkFullScreenState);
    document.addEventListener('webkitfullscreenchange', checkFullScreenState);
    document.addEventListener('mozfullscreenchange', checkFullScreenState);
    document.addEventListener('msfullscreenchange', checkFullScreenState);
    // F11 (browser fullscreen) usually triggers resize; watch resize to detect it
    window.addEventListener('resize', checkFullScreenState);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', function() {
        if (!fullScreenActive) return;
        tabSwitchCount += 1;
        showTabCount('Bạn đã chuyển tab ' + tabSwitchCount + ' lần.');
    });
});

function runTests() {
    var resultArea = document.getElementById('resultArea');
    resultArea.innerHTML = "<strong>Đang gửi bài và chạy test...</strong>";
    var formData = new FormData(document.getElementById('submitForm'));
    fetch('submit.php', { method: 'POST', body: formData })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        var html = '<h4>Kết quả:</h4>';
        data.forEach(function(res, index) {
            var color = res.status === 'Pass' ? 'green' : 'red';
            var icon = res.status === 'Pass' ? '✅' : '❌';
            html += '<div style="padding:5px; border-bottom:1px solid #eee; color:' + color + '">' + icon + ' Test ' + (index+1) + ': ' + res.status + '</div>';
        });
        resultArea.innerHTML = html;
    })
    .catch(function(err) { resultArea.innerHTML = "Lỗi kết nối!"; });
}
</script>
</body>
</html>