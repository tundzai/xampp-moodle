<?php
include 'config.php';

// Thiết lập để trả về định dạng JSON
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $problem_id = isset($_POST['problem_id']) ? intval($_POST['problem_id']) : 0;
    $user_code = $_POST['code'] ?? '';
    
    if ($problem_id === 0 || empty($user_code)) {
        echo json_encode(["error" => "Thiếu dữ liệu bài tập hoặc mã nguồn."]);
        exit;
    }

    // 1. Lấy thông tin bài tập
    $stmt = $conn->prepare("SELECT language_id FROM problems WHERE id = ?");
    $stmt->bind_param("i", $problem_id);
    $stmt->execute();
    $problem_data = $stmt->get_result()->fetch_assoc();
    
    if (!$problem_data) {
        echo json_encode(["error" => "Không tìm thấy bài tập."]);
        exit;
    }
    $lang = $problem_data['language_id'];

    // 2. Lấy danh sách Test Cases
    $test_stmt = $conn->prepare("SELECT input_data, expected_output FROM testcases WHERE problem_id = ?");
    $test_stmt->bind_param("i", $problem_id);
    $test_stmt->execute();
    $testcases = $test_stmt->get_result();

    $results = [];
    
    // 3. Vòng lặp chấm điểm
    while ($test = $testcases->fetch_assoc()) {
        $ch = curl_init(JOBE_URL);
        $payload = json_encode([
            "run_spec" => [
                "language_id" => $lang,
                "sourcecode" => $user_code,
                "input" => $test['input_data']
            ]
        ]);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-API-KEY: ' . JOBE_KEY
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Đợi tối đa 10s
        
        $raw_response = curl_exec($ch);
        $response = json_decode($raw_response, true);
        curl_close($ch);

        // Xử lý đầu ra thực tế từ Jobe
        $actual_output = isset($response['stdout']) ? trim($response['stdout']) : '';
        // Xử lý đáp án mong đợi từ Database
        $expected_output = trim($test['expected_output']);

        // So sánh
        // Lưu ý: Chúng ta dùng trim() để loại bỏ các ký tự xuống dòng dư thừa (\n, \r)
        if ($actual_output === $expected_output) {
            $results[] = [
                "status" => "Pass",
                "got" => $actual_output,
                "expected" => $expected_output
            ];
        } else {
            // Nếu có lỗi biên dịch (outcome = 12)
            if (isset($response['outcome']) && $response['outcome'] == 12) {
                $results[] = [
                    "status" => "Compile Error",
                    "details" => $response['cmpinfo'] ?? 'Lỗi cú pháp.'
                ];
            } else {
                // Sai kết quả
                $results[] = [
                    "status" => "Not Pass",
                    "got" => $actual_output,
                    "expected" => $expected_output
                ];
            }
        }
    }

    echo json_encode($results);
}
?>