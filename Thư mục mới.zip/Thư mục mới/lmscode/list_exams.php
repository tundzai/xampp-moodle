<?php 
include 'config.php'; 
$now = time(); // Lấy timestamp hiện tại
$exams = $conn->query("SELECT * FROM exams ORDER BY start_time DESC");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kỳ Thi - LMS CODE</title>
    <style>
        body { background: #000; color: #fff; font-family: sans-serif; padding: 40px; }
        h1 { text-transform: uppercase; border-bottom: 3px solid #00FF00; padding-bottom: 10px; display: inline-block; }
        .exam-item { background: #0a0a0a; border: 2px solid #333; padding: 25px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .btn { padding: 15px 30px; font-weight: bold; text-decoration: none; text-transform: uppercase; border-radius: 4px; display: inline-block; }
        .btn-active { background: #00FF00; color: #000; }
        .btn-locked { background: #222; color: #555; cursor: not-allowed; }
        .status { font-size: 0.75rem; font-weight: bold; padding: 5px 10px; border-radius: 3px; margin-bottom: 10px; display: inline-block; }
    </style>
</head>
<body>
    <a href="index.php" style="color:#888; text-decoration:none;">← QUAY LẠI</a><br><br>
    <h1>DANH SÁCH KỲ THI</h1>

    <div style="margin-top: 30px;">
        <?php while($row = $exams->fetch_assoc()): ?>
            <?php 
                $start = strtotime($row['start_time']);
                $end = strtotime($row['end_time']);
            ?>
            <div class="exam-item">
                <div>
                    <?php 
                        if ($now < $start) {
                            echo '<span class="status" style="background:#444;">SẮP DIỄN RA</span>';
                        } elseif ($now > $end) {
                            echo '<span class="status" style="background:#300; color:red;">ĐÃ KẾT THÚC</span>';
                        } else {
                            echo '<span class="status" style="background:#004400; color:#00FF00;">ĐANG DIỄN RA</span>';
                        }
                    ?>
                    <h2 style="margin:5px 0;"><?php echo $row['title']; ?></h2>
                    <small style="color:#888;">Khung giờ: <b><?php echo date('H:i d/m', $start); ?></b> - <b><?php echo date('H:i d/m', $end); ?></b></small>
                </div>

                <div>
                    <?php if ($now >= $start && $now <= $end): ?>
                        <a href="exam_view.php?exam_id=<?php echo $row['id']; ?>" class="btn btn-active">VÀO THI</a>
                    <?php else: ?>
                        <span class="btn btn-locked">ĐANG KHÓA</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>