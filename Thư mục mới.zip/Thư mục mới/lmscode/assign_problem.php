<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $e_id = intval($_POST['exam_id']);
    $p_id = intval($_POST['problem_id']);

    if ($e_id > 0 && $p_id > 0) {
        // Kiểm tra xem bài này đã gán vào kỳ thi này chưa để tránh trùng lặp
        $check = $conn->query("SELECT id FROM exam_problems WHERE exam_id = $e_id AND problem_id = $p_id");
        
        if ($check->num_rows == 0) {
            $stmt = $conn->prepare("INSERT INTO exam_problems (exam_id, problem_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $e_id, $p_id);
            if ($stmt->execute()) {
                echo "<script>alert('Đã thêm bài tập vào kỳ thi!'); window.location.href='admin.php';</script>";
            }
        } else {
            echo "<script>alert('Bài tập này đã có trong kỳ thi rồi!'); window.location.href='admin.php';</script>";
        }
    }
}
?>