<?php
include 'config.php';
$error = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        if (password_verify($pass, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            header("Location: index.php");
            exit();
        }
    }
    $error = "Sai tài khoản hoặc mật khẩu!";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập</title>
    <style>
        body { background: #000; color: #fff; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: #111; padding: 40px; border: 2px solid #333; border-radius: 10px; width: 320px; text-align: center; }
        input { width: 100%; padding: 12px; margin: 10px 0; background: #222; border: 1px solid #444; color: #fff; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #fff; color: #000; border: none; font-weight: bold; cursor: pointer; text-transform: uppercase; }
        h2 { font-weight: bold; letter-spacing: 1px; }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>LOGIN</h2>
        <?php if($error) echo "<p style='color:red'>$error</p>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">ĐĂNG NHẬP</button>
        </form>
        <p style="margin-top:15px; font-size:0.9rem;">Chưa có tài khoản? <a href="register.php" style="color:#aaa">Đăng ký ngay</a></p>
    </div>
</body>
</html>