<?php 
include 'config.php'; 
$result = $conn->query("SELECT * FROM problems ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách bài tập</title>
    <style>
        body { background: #000; color: #fff; font-family: sans-serif; padding: 40px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 15px; text-align: left; }
        th { background: #111; font-weight: bold; text-transform: uppercase; }
        tr:hover { background: #1a1a1a; }
        .btn-view { color: #007bff; font-weight: bold; text-decoration: none; }
        .back-link { color: #fff; text-decoration: none; display: inline-block; margin-bottom: 20px; }
    </style>
</head>
<body>
    <a href="index.php" class="back-link">← Quay lại Menu</a>
    <h1>Danh sách bài tập hiện có</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên bài tập</th>
                <th>Ngôn ngữ</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><strong><?php echo $row['title']; ?></strong></td>
                <td><?php echo strtoupper($row['language_id']); ?></td>
                <td>
                    <a href="view_problem.php?id=<?php echo $row['id']; ?>" class="btn-view">VÀO CHẤM CODE</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>