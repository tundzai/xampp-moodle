<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý đề bài</title>
    <style>
        body { font-family: sans-serif; margin: 20px; line-height: 1.6; }
        .testcase-group { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; background: #f9f9f9; }
        label { display: block; margin-top: 10px; font-weight: bold; }
        textarea, input, select { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 10px; padding: 10px 20px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Thêm đề bài mới</h1>
    <form action="save_problem.php" method="POST">
        <label>Tiêu đề bài tập:</label>
        <input type="text" name="title" required placeholder="Ví dụ: Tính tổng hai số">

        <label>Mô tả đề bài (HTML được chấp nhận):</label>
        <textarea name="description" rows="5" required placeholder="Nhập yêu cầu đề bài..."></textarea>

        <label>Ngôn ngữ lập trình:</label>
        <select name="language_id">
            <option value="cpp">C++ (cpp)</option>
            <option value="python3">Python 3 (python3)</option>
            <option value="java">Java (java)</option>
            <option value="c">C (c)</option>
        </select>

        <div id="testcase_container">
            <h3>Test Cases</h3>
            <div class="testcase-group">
                <label>Input mẫu:</label>
                <textarea name="test_input[]" rows="2"></textarea>
                <label>Output mong đợi:</label>
                <textarea name="test_output[]" rows="2" required></textarea>
            </div>
        </div>

        <button type="button" onclick="addTestCase()">+ Thêm Test Case</button>
        <hr>
        <button type="submit" style="background: #28a745; color: white; border: none;">Lưu bài tập</button>
    </form>

    <script>
        function addTestCase() {
            const container = document.getElementById('testcase_container');
            const div = document.createElement('div');
            div.className = 'testcase-group';
            div.innerHTML = `
                <label>Input mẫu:</label>
                <textarea name="test_input[]" rows="2"></textarea>
                <label>Output mong đợi:</label>
                <textarea name="test_output[]" rows="2" required></textarea>
                <button type="button" onclick="this.parentElement.remove()" style="color:red">Xóa Test Case này</button>
            `;
            container.appendChild(div);
        }
    </script>
</body>
</html>