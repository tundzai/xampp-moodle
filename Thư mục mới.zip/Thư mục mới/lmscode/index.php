<?php 
include 'config.php'; 

// Kiểm tra nếu chưa đăng nhập thì chuyển hướng về trang login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Lấy thông tin người dùng hiện tại
$u_id = $_SESSION['user_id'];
$user_res = $conn->query("SELECT username, points FROM users WHERE id = $u_id");
$user_data = $user_res->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LMS Code - Dashboard</title>
    <style>
        body {
            background-color: #000000;
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Thanh trạng thái người dùng */
        .user-bar {
            width: 100%;
            padding: 15px 30px;
            background: #111;
            border-bottom: 1px solid #333;
            display: flex;
            justify-content: space-between;
            box-sizing: border-box;
        }

        .user-info { font-weight: bold; font-size: 1.1rem; }
        .user-points { color: #FFD700; margin-left: 20px; } /* Màu vàng Gold cho điểm */

        h1 {
            margin-top: 50px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 4px;
        }

        .menu-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            width: 90%;
            max-width: 1100px;
            margin-top: 40px;
        }

        .menu-item {
            background-color: #0a0a0a;
            border: 2px solid #ffffff; /* Viền trắng in đậm */
            padding: 40px 20px;
            text-align: center;
            text-decoration: none;
            color: #ffffff;
            font-weight: 900; /* In cực đậm */
            font-size: 1.4rem;
            border-radius: 0; /* Để hình vuông cho nam tính */
            transition: 0.3s;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-transform: uppercase;
        }

        .menu-item:hover {
            background-color: #ffffff;
            color: #000000;
            box-shadow: 0 0 30px rgba(255, 255, 255, 0.4);
        }

        .menu-item .sub-text {
            font-weight: normal;
            font-size: 0.8rem;
            margin-top: 10px;
            text-transform: none;
            opacity: 0.6;
        }

        .logout-btn {
            border-color: #ff0000 !important;
            color: #ff0000 !important;
        }

        .logout-btn:hover {
            background-color: #ff0000 !important;
            color: #fff !important;
        }

        footer { margin-top: auto; padding: 30px; color: #333; font-size: 0.8rem; }
    </style>
</head>
<body>

    <div class="user-bar">
        <div class="user-info">
            USER: <?php echo strtoupper($user_data['username']); ?>
            <span class="user-points">SCORE: <?php echo $user_data['points']; ?> PTS</span>
        </div>
        <div class="status">● SYSTEM ONLINE</div>
    </div>

    <h1>LMS CODE SYSTEM</h1>

    <div class="menu-container">
        <a href="list_problems.php" class="menu-item">
            DANH SÁCH BÀI TẬP
            <span class="sub-text">Xem danh sách các bài thi và thực hành</span>
        </a>

        <a href="admin.php" class="menu-item">
            QUẢN TRỊ VIÊN
            <span class="sub-text">Thêm đề bài và quản lý Test Cases</span>
        </a>

        <a href="#" class="menu-item">
            BẢNG XẾP HẠNG
            <span class="sub-text">Xem vị trí của bạn trên hệ thống</span>
        </a>

        <a href="logout.php" class="menu-item logout-btn">
            ĐĂNG XUẤT
            <span class="sub-text">Thoát khỏi phiên làm việc hiện tại</span>
        </a>
    </div>

    <footer>HANOI UNIVERSITY OF SCIENCE AND TECHNOLOGY - 2026</footer>

</body>
</html>