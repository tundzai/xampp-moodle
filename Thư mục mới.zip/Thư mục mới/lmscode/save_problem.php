<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $lang = $_POST['language_id'];

    // 1. Lưu bài tập
    $stmt = $conn->prepare("INSERT INTO problems (title, description, language_id) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $desc, $lang);
    
    if ($stmt->execute()) {
        $problem_id = $conn->insert_id;

        // 2. Lưu Test Cases
        $inputs = $_POST['test_input'];
        $outputs = $_POST['test_output'];

        foreach ($inputs as $key => $val) {
            $in = $val;
            $out = $outputs[$key];
            if (!empty($out)) {
                $t_stmt = $conn->prepare("INSERT INTO testcases (problem_id, input_data, expected_output) VALUES (?, ?, ?)");
                $t_stmt->bind_param("iss", $problem_id, $in, $out);
                $t_stmt->execute();
            }
        }
        echo "Lưu thành công! <a href='view_problem.php?id=$problem_id'>Xem bài tập</a>";
    } else {
        echo "Lỗi: " . $conn->error;
    }
}
?>