<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$db   = "lmscode";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Kết nối DB thất bại");

// THÔNG TIN JOBE API CỦA BẠN
define('JOBE_URL', 'https://jobe2.cosc.canterbury.ac.nz/jobe/index.php/restapi/runs');
define('JOBE_KEY', '2AAA7A5415B4A9B394B54BF1D2E9D');
?>