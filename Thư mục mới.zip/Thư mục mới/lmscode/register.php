<?php
include 'config.php';
$msg = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check->bind_param("s", $user);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $msg = "Tên đăng nhập đã tồn tại!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $user, $pass);
        if ($stmt->execute()) {
            $msg = "Đăng ký thành công! <a href='login.php' style='color:cyan'>Đăng nhập ngay</a>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Đăng ký hệ thống</title>
    <style>
        body { background: #000; color: #fff; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: #111; padding: 40px; border: 2px solid #333; border-radius: 10px; width: 300px; }
        h2 { text-align: center; text-transform: uppercase; font-weight: bold; }
        input { width: 100%; padding: 10px; margin: 10px 0; background: #222; border: 1px solid #444; color: #fff; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #fff; color: #000; border: none; font-weight: bold; cursor: pointer; text-transform: uppercase; }
        button:hover { background: #ccc; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Đăng ký</h2>
        <?php if($msg) echo "<p style='color:orange'>$msg</p>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Tên đăng nhập" required>
            <input type="password" name="password" placeholder="Mật khẩu" required>
            <button type="submit">Xác nhận Đăng ký</button>
        </form>
        <p style="font-size: 0.8rem; text-align: center; margin-top: 15px;">
            Đã có tài khoản? <a href="login.php" style="color:#aaa">Đăng nhập</a>
        </p>
    </div>
</body>
</html>