<?php
include 'config.php';

if (!isset($_GET['exam_id'])) { header("Location: list_exams.php"); exit(); }

$exam_id = intval($_GET['exam_id']);
$now = time(); 

$exam = $conn->query("SELECT * FROM exams WHERE id = $exam_id")->fetch_assoc();
if (!$exam) die("Kỳ thi không tồn tại!");

$start = strtotime($exam['start_time']);
$end = strtotime($exam['end_time']);

// SO SÁNH THỜI GIAN DẠNG SỐ (TIMESTAMP) ĐỂ CHÍNH XÁC TUYỆT ĐỐI
if ($now < $start || $now > $end) {
    echo "<body style='background:#000; color:#fff; font-family:sans-serif; text-align:center; padding-top:100px;'>";
    echo "<h1 style='color:red; text-transform:uppercase;'>Ngoài thời gian thi cho phép!</h1>";
    echo "<div style='background:#111; padding:20px; display:inline-block; border:1px solid #333;'>";
    echo "<p>Giờ hệ thống hiện tại: <b style='color:#00FF00;'>" . date('H:i:s d/m/Y', $now) . "</b></p>";
    echo "<p>Kỳ thi này chỉ mở từ: <b>" . date('H:i:s d/m/Y', $start) . "</b></p>";
    echo "<p>Và kết thúc vào lúc: <b>" . date('H:i:s d/m/Y', $end) . "</b></p>";
    echo "</div><br><br>";
    echo "<a href='index.php' style='color:#aaa;'>[ Quay về trang chủ ]</a>";
    echo "</body>";
    exit();
}

$problems = $conn->query("SELECT p.id, p.title, p.language_id 
                         FROM problems p 
                         JOIN exam_problems ep ON p.id = ep.problem_id 
                         WHERE ep.exam_id = $exam_id");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo $exam['title']; ?></title>
    <style>
        body { background: #000; color: #fff; font-family: sans-serif; padding: 40px; }
        .problem-card { background:#111; border: 1px solid #333; padding: 20px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; }
        .btn-code { background: #00FF00; color: #000; padding: 10px 20px; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
    <h1 style="color:#00FF00;">DANH SÁCH BÀI THI: <?php echo strtoupper($exam['title']); ?></h1>
    <p>Kết thúc lúc: <?php echo date('H:i:s d/m/Y', $end); ?></p>
    <hr style="border:1px solid #333;">
    <div style="margin-top:20px;">
        <?php while($p = $problems->fetch_assoc()): ?>
            <div class="problem-card">
                <span><?php echo $p['title']; ?> (<?php echo strtoupper($p['language_id']); ?>)</span>
                <a href="view_problem.php?id=<?php echo $p['id']; ?>" class="btn-code">LÀM BÀI</a>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>