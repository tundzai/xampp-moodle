<?php 
include 'config.php'; 
$now = date('Y-m-d H:i:s');
$exams = $conn->query("SELECT * FROM exams ORDER BY start_time DESC");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kỳ thi trực tuyến - LMS CODE</title>
    <style>
        body { background: #000; color: #fff; font-family: sans-serif; padding: 40px; }
        h1 { text-transform: uppercase; border-bottom: 3px solid #f00; padding-bottom: 10px; font-weight: 900; }
        .exam-card { background: #111; border: 2px solid #333; padding: 25px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .btn-start { background: #00FF00; color: #000; padding: 15px 30px; text-decoration: none; font-weight: 900; }
        .btn-lock { background: #333; color: #666; padding: 15px 30px; text-decoration: none; pointer-events: none; }
    </style>
</head>
<body>
    <a href="index.php" style="color:#aaa; text-decoration:none;">← QUAY LẠI DASHBOARD</a>
    <h1>DANH SÁCH KỲ THI</h1>
    <div style="margin-top: 30px;">
        <?php while($ex = $exams->fetch_assoc()): ?>
            <div class="exam-card">
                <div>
                    <h2 style="margin:0; color:#00FF00;"><?php echo $ex['title']; ?></h2>
                    <p style="color:#888; margin:5px 0;">Bắt đầu: <?php echo $ex['start_time']; ?> | Kết thúc: <?php echo $ex['end_time']; ?></p>
                </div>
                <?php if ($now < $ex['start_time']): ?>
                    <span class="btn-lock">CHƯA MỞ</span>
                <?php elseif ($now > $ex['end_time']): ?>
                    <span class="btn-lock" style="color:red;">ĐÃ KẾT THÚC</span>
                <?php else: ?>
                    <a href="exam_view.php?exam_id=<?php echo $ex['id']; ?>" class="btn-start">VÀO THI</a>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>