<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['exam_title'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];

    $stmt = $conn->prepare("INSERT INTO exams (title, start_time, end_time) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $start, $end);

    if ($stmt->execute()) {
        echo "<script>alert('Tạo kỳ thi thành công!'); window.location.href='admin.php';</script>";
    } else {
        echo "Lỗi: " . $conn->error;
    }
}
?>