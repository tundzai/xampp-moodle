<?php
include("config/database.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    // kiểm tra trùng username
    $check = $conn->query("SELECT * FROM users WHERE username='$username'");

    if ($check->num_rows > 0) {
        echo "Username đã tồn tại!";
    } else {
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
        $conn->query($sql);
        echo "Đăng ký thành công! <a href='login.php'>Đăng nhập</a>";
    }
}
?>

<form method="POST">
    <h2>Đăng ký</h2>
    <input type="text" name="username" placeholder="Username" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>
    <button type="submit">Đăng ký</button>
</form>