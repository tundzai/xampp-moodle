<?php
require_once 'includes/header.php';

if (isset($_SESSION['user_id'])) {
    header("Location: problems.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['require_change'] = $user['require_password_change'];

        if ($user['require_password_change'] == 1) {
            header("Location: change_password.php");
        } else {
            header("Location: problems.php");
        }
        exit;
    } else {
        $error = "Tài khoản hoặc mật khẩu không chính xác.";
    }
}
?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card p-4">
            <h3 class="text-center mb-4 fw-bold text-success">ĐĂNG NHẬP</h3>
            <?php if($error): ?> <div class="alert alert-danger"><?= $error ?></div> <?php endif; ?>
            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Email tài khoản</label>
                    <input type="email" name="email" class="form-control" required placeholder="nhập email của bạn">
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-between">
                        <label class="form-label fw-semibold">Mật khẩu</label>
                        <a href="forgot_password.php" class="text-decoration-none small">Quên mật khẩu?</a>
                    </div>
                    <input type="password" name="password" class="form-control" required placeholder="nhập mật khẩu">
                </div>
                <button type="submit" class="btn btn-success w-100 py-2 fw-bold">Đăng Nhập</button>
            </form>
            <div class="text-center mt-3">
                Chưa có tài khoản? <a href="register.php" class="text-decoration-none">Đăng ký thành viên</a>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>