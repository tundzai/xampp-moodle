<?php
require_once 'includes/header.php';

// Fix: Cho phép cả teacher và admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) {
    header("Location: contests.php");
    exit;
}

$error = '';
$success = '';

$stmt = $pdo->query("SELECT id, title, language FROM problems ORDER BY id DESC");
$problems = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $selected_probs = $_POST['problems'] ?? [];

    if (empty($title) || empty($start_time) || empty($end_time)) {
        $error = "Vui lòng hoàn thành tiêu đề và cài đặt khung thời gian.";
    } elseif (count($selected_probs) == 0) {
        $error = "Bạn phải tích chọn ít nhất 1 bài tập từ danh sách cho kì thi này.";
    } elseif ($start_time >= $end_time) {
        $error = "Thời gian kết thúc kỳ thi phải sau thời gian bắt đầu khởi chạy.";
    } else {
        try {
            $pdo->beginTransaction();

            // Xử lý File SEB Upload
            $seb_path = null;
            if (isset($_FILES['seb_file']) && $_FILES['seb_file']['error'] == UPLOAD_ERR_OK) {
                $upload_dir = 'uploads/seb_configs/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                $filename = time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "", basename($_FILES['seb_file']['name']));
                $target_file = $upload_dir . $filename;
                if (move_uploaded_file($_FILES['seb_file']['tmp_name'], $target_file)) {
                    $seb_path = $target_file;
                }
            }

            $stmt = $pdo->prepare("INSERT INTO contests (title, start_time, end_time, seb_config_path) VALUES (?, ?, ?, ?)");
            $stmt->execute([$title, $start_time, $end_time, $seb_path]);
            $contest_id = $pdo->lastInsertId();

            $stmt_cp = $pdo->prepare("INSERT INTO contest_problems (contest_id, problem_id) VALUES (?, ?)");
            foreach ($selected_probs as $p_id) {
                $stmt_cp->execute([$contest_id, $p_id]);
            }

            $pdo->commit();
            $success = "Thiết lập thông số và kích hoạt kỳ thi mới thành công!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Lỗi CSDL phát sinh: " . $e->getMessage();
        }
    }
}
?>
<h2 class="fw-bold text-warning mb-4">🏆 Thiết Lập Kỳ Thi Lập Trình Mới</h2>
<?php if($error): ?> <div class="alert alert-danger border-danger bg-dark text-danger"><?= $error ?></div> <?php endif; ?>
<?php if($success): ?> <div class="alert alert-success border-success bg-dark text-success"><?= $success ?></div> <?php endif; ?>

<form action="create_contest.php" method="POST" enctype="multipart/form-data" class="card p-4">
    <div class="mb-3">
        <label class="form-label fw-bold">Tiêu đề kỳ thi</label>
        <input type="text" name="title" class="form-control" required placeholder="Ví dụ: Kiểm tra giữa kỳ lập trình nâng cao">
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <label class="form-label fw-bold">Ngày giờ bắt đầu cuộc thi</label>
            <input type="datetime-local" name="start_time" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label class="form-label fw-bold">Ngày giờ khóa đề đóng thi</label>
            <input type="datetime-local" name="end_time" class="form-control" required>
        </div>
    </div>

    <div class="mb-4 p-3 border border-danger rounded bg-dark">
        <label class="form-label fw-bold text-danger">🔒 Nhúng file cấu hình Safe Exam Browser (.seb) (Tùy chọn)</label>
        <input type="file" name="seb_file" class="form-control" accept=".seb">
        <small class="text-white-50 d-block mt-2">Nếu tải lên file cấu hình, học sinh BẮT BUỘC phải thực hiện quy trình mở khóa SEB trước khi thi.</small>
    </div>

    <hr class="border-secondary">
    <h5 class="fw-bold text-white mb-3">📚 Chọn các bài tập có sẵn đưa vào đề thi (Tùy ý số lượng)</h5>
    <div class="row">
        <?php if(count($problems) == 0): ?>
            <p class="text-danger ps-3">Hệ thống chưa có bài tập mẫu nào, vui lòng tạo bài tập trước.</p>
        <?php else: ?>
            <?php foreach($problems as $p): ?>
                <div class="col-md-6 mb-2">
                    <div class="form-check p-3 border rounded border-secondary" style="background-color: #0d0e12;">
                        <input class="form-check-input ms-1" type="checkbox" name="problems[]" value="<?= $p['id'] ?>" id="prob_<?= $p['id'] ?>">
                        <label class="form-check-label fw-semibold ms-2" for="prob_<?= $p['id'] ?>">
                            #<?= $p['id'] ?> - <?= htmlspecialchars($p['title']) ?> (<span class="small text-warning text-uppercase"><?= $p['language'] ?></span>)
                        </label>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="text-end mt-4">
        <a href="contests.php" class="btn btn-outline-secondary px-4 me-2">Hủy quay về</a>
        <button type="submit" class="btn btn-warning px-5 fw-bold text-dark">Lưu và Mở Đăng Ký Thi</button>
    </div>
</form>
<?php require_once 'includes/footer.php'; ?>