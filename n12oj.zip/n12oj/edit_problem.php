<?php
require_once 'includes/header.php';

// [ĐÃ CẬP NHẬT] Giáo viên và Admin đều được quyền truy cập trang sửa bài
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) {
    header("Location: problems.php"); exit;
}

$problem_id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM problems WHERE id = ?");
$stmt->execute([$problem_id]);
$problem = $stmt->fetch();

if (!$problem) die("Không tìm thấy bài tập.");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $desc = trim($_POST['description']);
    $lang = $_POST['language'];

    if (!empty($title) && !empty($lang)) {
        $stmt_up = $pdo->prepare("UPDATE problems SET title = ?, description = ?, language = ? WHERE id = ?");
        $stmt_up->execute([$title, $desc, $lang, $problem_id]);
        echo "<script>alert('Cập nhật bài tập thành công!'); window.location='problems.php';</script>";
        exit;
    }
}
?>
<h2 class="fw-bold text-info mb-4">✏️ Chỉnh Sửa Bài Tập Code #<?= $problem_id ?></h2>
<form action="" method="POST" class="card p-4">
    <div class="mb-3">
        <label class="form-label fw-bold">Tiêu đề bài tập</label>
        <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($problem['title']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-bold">Mô tả chi tiết</label>
        <textarea name="description" class="form-control" rows="5" required><?= htmlspecialchars($problem['description']) ?></textarea>
    </div>
    <div class="mb-4">
        <label class="form-label fw-bold">Ngôn ngữ yêu cầu</label>
        <select name="language" class="form-select" required>
            <option value="python3" <?= $problem['language'] == 'python3' ? 'selected' : '' ?>>Python 3</option>
            <option value="cpp" <?= $problem['language'] == 'cpp' ? 'selected' : '' ?>>C++ (GCC)</option>
            <option value="java" <?= $problem['language'] == 'java' ? 'selected' : '' ?>>Java</option>
        </select>
    </div>
    <div class="text-end">
        <a href="problems.php" class="btn btn-outline-secondary me-2">Hủy bỏ</a>
        <button type="submit" class="btn btn-info text-dark fw-bold px-4">Lưu Thay Đổi</button>
    </div>
</form>
<?php require_once 'includes/footer.php'; ?>