<?php
require_once 'includes/header.php';
// Fix: Cho phép cả teacher và admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) { header("Location: quizzes.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['title'])) {
    $title = trim($_POST['title']);
    $duration = (int)$_POST['duration'];
    $questions = $_POST['questions'] ?? [];

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO quizzes (title, duration_minutes) VALUES (?, ?)");
        $stmt->execute([$title, $duration]);
        $quiz_id = $pdo->lastInsertId();

        foreach ($questions as $q) {
            $q_text = trim($q['text']);
            if (empty($q_text)) continue;
            
            $stmt_q = $pdo->prepare("INSERT INTO questions (quiz_id, question_text) VALUES (?, ?)");
            $stmt_q->execute([$quiz_id, $q_text]);
            $question_id = $pdo->lastInsertId();

            if (isset($q['options'])) {
                foreach ($q['options'] as $opt_index => $opt_text) {
                    $o_text = trim($opt_text);
                    if (empty($o_text)) continue;
                    $is_correct = isset($q['correct']) && in_array($opt_index, $q['correct']) ? 1 : 0;
                    
                    $stmt_o = $pdo->prepare("INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)");
                    $stmt_o->execute([$question_id, $o_text, $is_correct]);
                }
            }
        }
        $pdo->commit();
        echo "<script>alert('Tạo Quiz Thành Công!'); window.location='quizzes.php';</script>";
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Lỗi: " . $e->getMessage();
    }
}
?>
<style>
.create-check { appearance: none; width: 24px; height: 24px; border: 2px solid #fff; border-radius: 4px; background-color: transparent; cursor: pointer; position: relative; margin-left: 15px; }
.create-check:checked::after { content: 'x'; position: absolute; color: #fff; font-size: 18px; font-weight: bold; top: 50%; left: 50%; transform: translate(-50%, -60%); }
</style>

<h2 class="fw-bold text-warning mb-4">🛠️ Tạo Quiz Mới</h2>
<?php if(isset($error)): ?> <div class="alert alert-danger border-danger bg-dark text-danger"><?= $error ?></div> <?php endif; ?>

<form action="create_quiz.php" method="POST" id="quizForm">
    <div class="card p-4">
        <div class="row">
            <div class="col-md-8">
                <label class="fw-bold">Tiêu đề Quiz (Ví dụ: Trắc Nghiệm C++)</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="fw-bold">Thời gian làm bài (Phút)</label>
                <input type="number" name="duration" class="form-control" required min="1" value="15">
            </div>
        </div>
    </div>

    <div id="questions-container"></div>
    
    <button type="button" class="btn btn-outline-info w-100 mb-4 py-2 fw-bold" onclick="addQuestion()">+ Thêm Câu Hỏi Mới</button>
    <div class="text-end">
        <button type="submit" class="btn btn-primary px-5 py-2 fw-bold text-dark fs-5">Thành Công (Lưu Quiz)</button>
    </div>
</form>

<script>
let qIndex = 0;
function addQuestion() {
    const container = document.getElementById('questions-container');
    const html = `
    <div class="card p-4 border-warning mb-4 question-block">
        <div class="d-flex justify-content-between mb-2">
            <h5 class="fw-bold text-info">Câu hỏi ${qIndex + 1}</h5>
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.question-block').remove()">Xóa câu này</button>
        </div>
        <textarea name="questions[${qIndex}][text]" class="form-control mb-3" placeholder="Nhập tiêu đề câu hỏi..." required rows="2"></textarea>
        
        <div id="opts_${qIndex}"></div>
        <button type="button" class="btn btn-sm btn-outline-light mt-3" onclick="addOption(${qIndex})">+ Thêm đáp án</button>
    </div>`;
    container.insertAdjacentHTML('beforeend', html);
    addOption(qIndex); addOption(qIndex); 
    qIndex++;
}

function addOption(qId) {
    const optContainer = document.getElementById(`opts_${qId}`);
    const oIndex = optContainer.children.length;
    const html = `
    <div class="d-flex align-items-center mb-2">
        <input type="text" name="questions[${qId}][options][${oIndex}]" class="form-control" placeholder="Nhập nội dung đáp án..." required>
        <input type="checkbox" name="questions[${qId}][correct][]" value="${oIndex}" class="create-check" title="Tick nếu đây là đáp án đúng">
    </div>`;
    optContainer.insertAdjacentHTML('beforeend', html);
}
addQuestion();
</script>
<?php require_once 'includes/footer.php'; ?>