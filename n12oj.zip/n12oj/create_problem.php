<?php
require_once 'includes/header.php';

// Fix: Cho phép cả teacher và admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) {
    header("Location: problems.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $language = $_POST['language'];
    $inputs = $_POST['inputs'] ?? [];
    $outputs = $_POST['outputs'] ?? [];

    if (empty($title) || empty($language)) {
        $error = "Vui lòng nhập tiêu đề bài và lựa chọn ngôn ngữ lập trình.";
    } elseif (count($outputs) == 0) {
        $error = "Bạn phải tạo ít nhất một Testcase (đầu ra mong muốn không được bỏ trống).";
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO problems (title, language) VALUES (?, ?)");
            $stmt->execute([$title, $language]);
            $problem_id = $pdo->lastInsertId();

            $stmt_tc = $pdo->prepare("INSERT INTO testcases (problem_id, input_data, expected_output) VALUES (?, ?, ?)");
            for ($i = 0; $i < count($outputs); $i++) {
                $in_data = $inputs[$i] ?? '';
                $out_data = $outputs[$i];
                if (trim($out_data) === '') continue; 
                $stmt_tc->execute([$problem_id, $in_data, $out_data]);
            }

            $pdo->commit();
            $success = "Tạo đề bài tập mới kèm các testcase thành công!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Lỗi hệ thống CSDL: " . $e->getMessage();
        }
    }
}
?>
<h2 class="fw-bold text-primary mb-4">🛠️ Tạo Bài Tập Mới</h2>
<?php if($error): ?> <div class="alert alert-danger border-danger bg-dark text-danger"><?= $error ?></div> <?php endif; ?>
<?php if($success): ?> <div class="alert alert-success border-success bg-dark text-success"><?= $success ?></div> <?php endif; ?>

<form action="create_problem.php" method="POST" class="card p-4">
    <div class="row mb-3">
        <div class="col-md-8">
            <label class="form-label fw-bold">Tiêu đề bài tập</label>
            <input type="text" name="title" class="form-control" required placeholder="Ví dụ: Tính tổng hai số A và B">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-bold">Ngôn ngữ lập trình bắt buộc</label>
            <select name="language" class="form-select" required>
                <option value="python3">Python 3</option>
                <option value="c">Ngôn ngữ C</option>
                <option value="cpp">Ngôn ngữ C++</option>
                <option value="java">Java</option>
                <option value="nodejs">JavaScript (Node.js)</option>
                <option value="php">Ngôn ngữ PHP</option>
            </select>
        </div>
    </div>

    <hr class="border-secondary">
    <h4 class="fw-bold text-white mb-3">📋 Danh sách các bộ Testcase mẫu</h4>
    <div id="testcase-container">
        <div class="card p-3 border-secondary mb-3 testcase-item" style="background-color: #0d0e12;">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge bg-secondary">Testcase #1</span>
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="removeTestcase(this)">Xóa bộ này</button>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Dữ liệu đầu vào (Input)</label>
                    <textarea name="inputs[]" class="form-control rows-2" placeholder="Nhập dữ liệu đầu vào nếu có..."></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-warning">Kết quả mong đợi (Expected Output) *</label>
                    <textarea name="outputs[]" class="form-control rows-2" required placeholder="Kết quả đầu ra chính xác..."></textarea>
                </div>
            </div>
        </div>
    </div>

    <button type="button" class="btn btn-outline-info mb-4 w-100" onclick="addTestcase()">+ Thêm bộ Testcase mới</button>
    
    <div class="text-end">
        <a href="problems.php" class="btn btn-outline-secondary px-4 me-2">Quay lại</a>
        <button type="submit" class="btn btn-primary px-5 fw-bold text-dark">Lưu và Xuất bản bài tập</button>
    </div>
</form>

<script>
let tcCount = 1;
function addTestcase() {
    tcCount++;
    const container = document.getElementById('testcase-container');
    const div = document.createElement('div');
    div.className = 'card p-3 border-secondary mb-3 testcase-item';
    div.style.backgroundColor = '#0d0e12';
    div.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="badge bg-secondary">Testcase #${tcCount}</span>
            <button type="button" class="btn btn-outline-danger btn-sm" onclick="removeTestcase(this)">Xóa bộ này</button>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label class="form-label small fw-bold">Dữ liệu đầu vào (Input)</label>
                <textarea name="inputs[]" class="form-control rows-2" placeholder="Nhập dữ liệu đầu vào nếu có..."></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold text-warning">Kết quả mong đợi (Expected Output) *</label>
                <textarea name="outputs[]" class="form-control rows-2" required placeholder="Kết quả đầu ra chính xác..."></textarea>
            </div>
        </div>
    `;
    container.appendChild(div);
}

function removeTestcase(button) {
    const items = document.getElementsByClassName('testcase-item');
    if (items.length <= 1) {
        alert("Bài tập bắt buộc phải có tối thiểu 1 bộ testcase.");
        return;
    }
    button.closest('.testcase-item').remove();
}
</script>
<?php require_once 'includes/footer.php'; ?>