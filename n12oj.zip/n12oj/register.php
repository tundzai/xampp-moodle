<?php
require_once 'includes/header.php';

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = 'student'; // Ép buộc mặc định 100% là student

    if (empty($email) || empty($password)) {
        $error = "Vui lòng điền đầy đủ các thông tin.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Định dạng email không hợp lệ.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email này đã được sử dụng.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO users (email, password, role) VALUES (?, ?, ?)");
            if ($stmt->execute([$email, $hashed_password, $role])) {
                $success = "Đăng ký thành công! Vai trò mặc định của bạn là Học Sinh.";
            } else {
                $error = "Đã xảy ra lỗi hệ thống khi đăng ký.";
            }
        }
    }
}
?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card p-5 border-0 shadow-lg" style="background: linear-gradient(145deg, #16171e, #0d0e12);">
            <div class="text-center mb-4">
                <h2 class="fw-bold text-white mb-1">TẠO TÀI KHOẢN MỚI</h2>
                <p class="text-muted small">Nền tảng học tập trực tuyến</p>
            </div>
            
            <?php if($error): ?> <div class="alert alert-danger border-danger text-danger bg-dark"><?= $error ?></div> <?php endif; ?>
            <?php if($success): ?> <div class="alert alert-success border-success text-success bg-dark"><?= $success ?></div> <?php endif; ?>
            
            <form action="register.php" method="POST">
                <div class="mb-4">
                    <label class="form-label text-white-50 small text-uppercase fw-bold">Địa chỉ Email</label>
                    <input type="email" name="email" class="form-control" required placeholder="name@example.com">
                </div>
                <div class="mb-4">
                    <label class="form-label text-white-50 small text-uppercase fw-bold">Mật khẩu</label>
                    <input type="password" name="password" class="form-control" required placeholder="Tạo mật khẩu an toàn">
                </div>
                <div class="mb-4 text-center">
                    <span class="badge bg-secondary p-2 w-100">Vai trò mặc định: Học sinh (Student)</span>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 py-3 fw-bold text-uppercase mt-2">Đăng Ký Hệ Thống</button>
            </form>
            <div class="text-center mt-4 pt-3 border-top" style="border-color: #232530 !important;">
                <span class="text-white-50">Đã có tài khoản?</span> <a href="login.php" class="text-primary text-decoration-none fw-bold ms-1">Đăng nhập ngay</a>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>