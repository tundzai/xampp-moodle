<?php
require_once 'includes/header.php';
$course_id = $_GET['id'] ?? 0;
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) { header("Location: courses.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_students'])) {
    $selected_users = $_POST['students'] ?? [];
    $pdo->prepare("DELETE FROM course_enrollments WHERE course_id = ?")->execute([$course_id]);
    $stmt_ins = $pdo->prepare("INSERT INTO course_enrollments (course_id, user_id) VALUES (?, ?)");
    foreach ($selected_users as $uid) { $stmt_ins->execute([$course_id, $uid]); }
    echo "<script>alert('Cập nhật danh sách thành công!'); window.location='course_view.php?id=$course_id';</script>"; exit;
}

// Lấy danh sách all students và check xem ai đã enroll
$students = $pdo->query("SELECT id, email FROM users WHERE role = 'student' ORDER BY email ASC")->fetchAll();
$enrolled = $pdo->prepare("SELECT user_id FROM course_enrollments WHERE course_id = ?");
$enrolled->execute([$course_id]);
$enrolled_ids = $enrolled->fetchAll(PDO::FETCH_COLUMN);
?>
<h2 class="fw-bold text-warning mb-4">👥 Quản lý Học Sinh Khóa Học</h2>
<form method="POST" class="card p-4">
    <div class="mb-3 d-flex justify-content-between border-bottom border-secondary pb-2">
        <span class="fw-bold text-white">Tích chọn để thêm học sinh vào lớp:</span>
        <a href="course_view.php?id=<?= $course_id ?>" class="btn btn-sm btn-outline-secondary">Quay lại khóa học</a>
    </div>
    <div class="row">
        <?php foreach($students as $s): ?>
            <div class="col-md-4 mb-2">
                <label class="form-check p-3 border rounded border-secondary" style="background-color: #16171e; cursor:pointer;">
                    <input type="checkbox" name="students[]" value="<?= $s['id'] ?>" class="form-check-input ms-1" <?= in_array($s['id'], $enrolled_ids) ? 'checked' : '' ?>>
                    <span class="ms-2 text-white"><?= htmlspecialchars($s['email']) ?></span>
                </label>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="mt-4 text-end">
        <button type="submit" name="update_students" class="btn btn-warning fw-bold text-dark px-5">Lưu Danh Sách</button>
    </div>
</form>
<?php require_once 'includes/footer.php'; ?>