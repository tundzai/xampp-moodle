<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) { header("Location: courses.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $desc = trim($_POST['description']);
    if (!empty($title)) {
        $stmt = $pdo->prepare("INSERT INTO courses (title, description, teacher_id) VALUES (?, ?, ?)");
        $stmt->execute([$title, $desc, $_SESSION['user_id']]);
        header("Location: courses.php"); exit;
    }
}
?>
<h2 class="fw-bold text-info mb-4">📝 Tạo Khóa Học Mới</h2>
<form action="" method="POST" class="card p-4">
    <div class="mb-3">
        <label class="form-label fw-bold">Tên Khóa Học *</label>
        <input type="text" name="title" class="form-control" required placeholder="Ví dụ: Lập trình C++ Cơ bản (Lớp K12)">
    </div>
    <div class="mb-4">
        <label class="form-label fw-bold">Mô tả Khóa Học</label>
        <textarea name="description" class="form-control" rows="4" placeholder="Nhập tóm tắt nội dung..."></textarea>
    </div>
    <div class="text-end">
        <a href="courses.php" class="btn btn-outline-secondary me-2">Hủy bỏ</a>
        <button type="submit" class="btn btn-info text-dark fw-bold px-4">Tạo & Lưu</button>
    </div>
</form>
<?php require_once 'includes/footer.php'; ?>