<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$course_id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// 1. Kiểm tra quyền truy cập (Admin, Teacher chủ khóa, hoặc Student đã Enroll)
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?"); $stmt->execute([$course_id]);
$course = $stmt->fetch();
if (!$course) die("Khóa học không tồn tại.");

$is_owner = ($role == 'admin' || ($role == 'teacher' && $course['teacher_id'] == $user_id));

if (!$is_owner) {
    $stmt_check = $pdo->prepare("SELECT 1 FROM course_enrollments WHERE course_id = ? AND user_id = ?");
    $stmt_check->execute([$course_id, $user_id]);
    if (!$stmt_check->fetch()) {
        echo "<div class='alert alert-danger text-center mt-5'>Bạn không có quyền truy cập khóa học này.</div>"; exit;
    }
}

// 2. Fetch Materials, Problems, Quizzes
$materials = $pdo->prepare("SELECT * FROM course_materials WHERE course_id = ? ORDER BY id DESC"); $materials->execute([$course_id]);
$mats = $materials->fetchAll();

// Problems with relative Status inside Course
$stmt_probs = $pdo->prepare("
    SELECT p.*,
           (SELECT MAX(CASE WHEN status = 'Accepted' THEN 2 ELSE 1 END) 
            FROM submissions s WHERE s.problem_id = p.id AND s.user_id = ? AND s.course_id = ?) as user_status
    FROM problems p JOIN course_problems cp ON p.id = cp.problem_id WHERE cp.course_id = ?
");
$stmt_probs->execute([$user_id, $course_id, $course_id]); $probs = $stmt_probs->fetchAll();

// Quizzes with relative Score
$stmt_quiz = $pdo->prepare("
    SELECT q.*,
           (SELECT MAX(score) FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.user_id = ? AND qa.course_id = ? AND status='completed') as user_score
    FROM quizzes q JOIN course_quizzes cq ON q.id = cq.quiz_id WHERE cq.course_id = ?
");
$stmt_quiz->execute([$user_id, $course_id, $course_id]); $quizzes = $stmt_quiz->fetchAll();

// 3. LOGIC TẠO DASHBOARD THỐNG KÊ (DÀNH CHO GIÁO VIÊN/ADMIN)
$quiz_stats = [];
if ($is_owner) {
    foreach ($quizzes as $q) {
        $q_id = $q['id'];
        
        // Tổng số người làm
        $s1 = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM quiz_attempts WHERE quiz_id = ? AND course_id = ? AND status='completed'");
        $s1->execute([$q_id, $course_id]); $total_users = $s1->fetchColumn();
        
        // Điểm TB
        $s2 = $pdo->prepare("SELECT AVG(score) FROM quiz_attempts WHERE quiz_id = ? AND course_id = ? AND status='completed'");
        $s2->execute([$q_id, $course_id]); $avg_score = round($s2->fetchColumn() ?: 0, 1);
        
        // Câu hỏi sai nhiều nhất (Khó nhất)
        $s3 = $pdo->prepare("
            SELECT q_text.question_text, COUNT(aa.option_id) as wrong_count
            FROM attempt_answers aa
            JOIN quiz_attempts qa ON aa.attempt_id = qa.id
            JOIN options o ON aa.option_id = o.id
            JOIN questions q_text ON aa.question_id = q_text.id
            WHERE qa.quiz_id = ? AND qa.course_id = ? AND o.is_correct = 0 AND qa.status='completed'
            GROUP BY q_text.id ORDER BY wrong_count DESC LIMIT 1
        ");
        $s3->execute([$q_id, $course_id]); $worst_q = $s3->fetch();
        
        $quiz_stats[] = [
            'title' => $q['title'],
            'users' => $total_users,
            'avg' => $avg_score,
            'worst_text' => $worst_q ? $worst_q['question_text'] : "Chưa đủ dữ liệu",
            'worst_count' => $worst_q ? $worst_q['wrong_count'] : 0,
            'total_q' => $pdo->prepare("SELECT COUNT(*) FROM questions WHERE quiz_id=?")->execute([$q_id]) ? $pdo->query("SELECT FOUND_ROWS()")->fetchColumn() : 1
        ];
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-info pb-3">
    <h2 class="fw-bold text-info mb-0">🎓 Khóa học: <?= htmlspecialchars($course['title']) ?></h2>
    <?php if($is_owner): ?>
        <div>
            <a href="course_manage_students.php?id=<?= $course_id ?>" class="btn btn-outline-warning fw-bold me-2">👥 Quản lý Học sinh</a>
            <a href="course_add_content.php?id=<?= $course_id ?>" class="btn btn-success fw-bold text-dark">➕ Thêm Nội Dung</a>
        </div>
    <?php endif; ?>
</div>

<div class="row">
    <!-- 70% BÊN TRÁI: NỘI DUNG HỌC TẬP -->
    <div class="col-lg-8 mb-4">
        
        <!-- SECTION TÀI LIỆU -->
        <h4 class="fw-bold text-white mb-3">📁 Tài Liệu Bài Giảng</h4>
        <?php if(count($mats) == 0): ?><p class="text-muted fst-italic">Chưa có tài liệu nào.</p><?php endif; ?>
        <?php foreach($mats as $m): ?>
            <a href="<?= htmlspecialchars($m['link_url']) ?>" target="_blank" class="card p-3 mb-2 text-decoration-none" style="background-color: #16171e; border: 1px solid #232530; transition: 0.2s;" onmouseover="this.style.borderColor='#3b82f6'" onmouseout="this.style.borderColor='#232530'">
                <div class="d-flex align-items-center">
                    <span class="fs-4 me-3"><?= $m['material_type'] == 'video' ? '📺' : ($m['material_type'] == 'document' ? '📄' : '🔗') ?></span>
                    <h6 class="text-info fw-bold mb-0"><?= htmlspecialchars($m['title']) ?></h6>
                    <span class="ms-auto text-white-50 small">Mở liên kết ↗</span>
                </div>
            </a>
        <?php endforeach; ?>

        <!-- SECTION TRẮC NGHIỆM -->
        <h4 class="fw-bold text-white mt-5 mb-3">📝 Bài Trắc Nghiệm (Quiz)</h4>
        <?php if(count($quizzes) == 0): ?><p class="text-muted fst-italic">Chưa có bài Quiz nào.</p><?php endif; ?>
        <div class="row">
        <?php foreach($quizzes as $q): ?>
            <div class="col-md-6 mb-3">
                <div class="card p-3 border-warning h-100">
                    <h5 class="fw-bold text-white mb-1"><?= htmlspecialchars($q['title']) ?></h5>
                    <p class="text-white-50 small mb-3">Điểm cao nhất: <strong class="text-success"><?= $q['user_score'] !== null ? $q['user_score'] . ' điểm' : 'Chưa làm' ?></strong></p>
                    <a href="take_quiz.php?id=<?= $q['id'] ?>&course_id=<?= $course_id ?>" class="btn btn-sm btn-warning fw-bold mt-auto text-dark">Làm bài Quiz</a>
                </div>
            </div>
        <?php endforeach; ?>
        </div>

        <!-- SECTION BÀI TẬP CODE -->
        <h4 class="fw-bold text-white mt-4 mb-3">💻 Bài Tập Lập Trình</h4>
        <?php if(count($probs) == 0): ?><p class="text-muted fst-italic">Chưa có bài tập Code nào.</p><?php endif; ?>
        <?php foreach($probs as $p): 
            $status_text = 'Chưa làm'; $status_color = '#ef4444';
            if ($p['user_status'] == 2) { $status_text = 'Hoàn thành'; $status_color = '#10b981'; }
            elseif ($p['user_status'] == 1) { $status_text = 'Đã nộp sai'; $status_color = '#f59e0b'; }
        ?>
            <div class="card p-3 mb-2" style="background-color: #16171e; border-left: 4px solid <?= $status_color ?> !important;">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white fw-bold mb-1"><?= htmlspecialchars($p['title']) ?></h6>
                        <small style="color: <?= $status_color ?>; font-weight: bold;">● <?= $status_text ?></small>
                    </div>
                    <a href="solve.php?id=<?= $p['id'] ?>&course_id=<?= $course_id ?>" class="btn btn-sm btn-outline-light">Giải bài</a>
                </div>
            </div>
        <?php endforeach; ?>

    </div>

    <!-- 30% BÊN PHẢI: DASHBOARD THỐNG KÊ (Chỉ GV/Admin) -->
    <div class="col-lg-4">
        <?php if($is_owner): ?>
            <div class="card p-4 border-info position-sticky" style="top: 20px;">
                <h5 class="fw-bold text-info border-bottom border-secondary pb-2 mb-3">📊 Thống Kê Lớp Học</h5>
                
                <?php if(count($quiz_stats) == 0): ?>
                    <p class="text-muted small italic">Hãy thêm Bài Quiz vào khóa học để xem biểu đồ thống kê.</p>
                <?php else: ?>
                    <?php foreach($quiz_stats as $stat): 
                        // Vẽ biểu đồ thanh ngang (CSS Progress bar) dựa trên điểm TB / Tổng câu hỏi
                        $percent_correct = min(100, max(0, ($stat['avg'] / $stat['total_q']) * 100)); 
                    ?>
                        <div class="mb-4">
                            <h6 class="fw-bold text-warning mb-1"><?= htmlspecialchars($stat['title']) ?></h6>
                            <div class="d-flex justify-content-between small text-white-50 mb-1">
                                <span>👥 Đã làm: <b><?= $stat['users'] ?>hs</b></span>
                                <span>Trung bình: <b><?= $stat['avg'] ?>đ</b></span>
                            </div>
                            
                            <!-- Biểu đồ cột ngang (Progress Bar) -->
                            <div class="progress mb-2" style="height: 10px; background-color: #232530;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: <?= $percent_correct ?>%;"></div>
                            </div>
                            
                            <div class="p-2 rounded mt-2" style="background-color: #0d0e12; border: 1px solid #ef4444;">
                                <small class="text-danger fw-bold d-block mb-1">⚠️ Câu sai nhiều nhất:</small>
                                <small class="text-white-50 d-block text-truncate" title="<?= htmlspecialchars($stat['worst_text']) ?>">
                                    <?= htmlspecialchars($stat['worst_text']) ?>
                                </small>
                                <small class="text-danger float-end">- <?= $stat['worst_count'] ?> lượt sai</small>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <!-- Học sinh thấy thông báo -->
            <div class="card p-4 border-success">
                <h5 class="fw-bold text-success text-center">Tiến độ cá nhân</h5>
                <p class="text-center text-white-50 small mt-2">Bạn đang làm rất tốt, hãy cố gắng hoàn thành các bài tập bên trái nhé!</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>