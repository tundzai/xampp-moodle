<?php
require_once 'includes/header.php';
$course_id = $_GET['id'] ?? 0;
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) { header("Location: courses.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $type = $_POST['type'];
    try {
        if ($type == 'material') {
            $title = trim($_POST['title']); $url = trim($_POST['url']); $mat_type = $_POST['mat_type'];
            $pdo->prepare("INSERT INTO course_materials (course_id, title, link_url, material_type) VALUES (?, ?, ?, ?)")->execute([$course_id, $title, $url, $mat_type]);
        } 
        // [MỚI] Xử lý mảng (array) khi tích chọn nhiều Problem
        elseif ($type == 'problem' && !empty($_POST['problem_ids'])) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO course_problems (course_id, problem_id) VALUES (?, ?)");
            foreach ($_POST['problem_ids'] as $pid) {
                $stmt->execute([$course_id, $pid]);
            }
        } 
        // [MỚI] Xử lý mảng (array) khi tích chọn nhiều Quiz
        elseif ($type == 'quiz' && !empty($_POST['quiz_ids'])) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO course_quizzes (course_id, quiz_id) VALUES (?, ?)");
            foreach ($_POST['quiz_ids'] as $qid) {
                $stmt->execute([$course_id, $qid]);
            }
        }
        header("Location: course_view.php?id=$course_id"); exit;
    } catch(Exception $e) { $error = $e->getMessage(); }
}

$all_probs = $pdo->query("SELECT id, title FROM problems ORDER BY id DESC")->fetchAll();
$all_quizzes = $pdo->query("SELECT id, title FROM quizzes ORDER BY id DESC")->fetchAll();
?>
<h2 class="fw-bold text-success mb-4">➕ Thêm Nội Dung Khóa Học</h2>
<a href="course_view.php?id=<?= $course_id ?>" class="btn btn-outline-secondary mb-4">⬅ Quay lại khóa học</a>

<div class="row">
    <div class="col-md-4 mb-4">
        <form method="POST" class="card p-4 h-100 border-info">
            <h5 class="fw-bold text-info">1. Upload Tài Liệu (URL Link)</h5>
            <input type="hidden" name="type" value="material">
            <div class="mb-3 mt-3">
                <label class="small fw-bold">Tiêu đề (VD: Bài giảng số 1)</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="small fw-bold">Đường Link (YouTube, Drive)</label>
                <input type="url" name="url" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="small fw-bold">Loại tài liệu</label>
                <select name="mat_type" class="form-select">
                    <option value="video">🎥 Video (Youtube/Drive)</option>
                    <option value="document">📄 Văn bản (Word/PDF)</option>
                    <option value="other">🔗 Link Khác</option>
                </select>
            </div>
            <button class="btn btn-info mt-auto text-dark fw-bold">Thêm Tài Liệu</button>
        </form>
    </div>

    <div class="col-md-4 mb-4">
        <form method="POST" class="card p-4 h-100 border-warning">
            <h5 class="fw-bold text-warning">2. Gán Bài Trắc Nghiệm</h5>
            <input type="hidden" name="type" value="quiz">
            <div class="mb-3 mt-3">
                <label class="small fw-bold mb-2">Tích chọn các bài Quiz muốn gán (Có thể chọn nhiều)</label>
                <div class="p-2 rounded border border-secondary" style="max-height: 200px; overflow-y: auto; background-color: #0d0e12;">
                    <?php foreach($all_quizzes as $q): ?>
                        <div class="form-check mb-1">
                            <input class="form-check-input" type="checkbox" name="quiz_ids[]" value="<?= $q['id'] ?>" id="q_<?= $q['id'] ?>">
                            <label class="form-check-label text-white" for="q_<?= $q['id'] ?>">
                                <?= htmlspecialchars($q['title']) ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <button class="btn btn-warning mt-auto text-dark fw-bold">Gán Quiz Vào Lớp</button>
        </form>
    </div>

    <div class="col-md-4 mb-4">
        <form method="POST" class="card p-4 h-100 border-success">
            <h5 class="fw-bold text-success">3. Gán Bài Tập Lập Trình</h5>
            <input type="hidden" name="type" value="problem">
            <div class="mb-3 mt-3">
                <label class="small fw-bold mb-2">Tích chọn các bài Code muốn gán (Có thể chọn nhiều)</label>
                <div class="p-2 rounded border border-secondary" style="max-height: 200px; overflow-y: auto; background-color: #0d0e12;">
                    <?php foreach($all_probs as $p): ?>
                        <div class="form-check mb-1">
                            <input class="form-check-input" type="checkbox" name="problem_ids[]" value="<?= $p['id'] ?>" id="p_<?= $p['id'] ?>">
                            <label class="form-check-label text-white" for="p_<?= $p['id'] ?>">
                                #<?= $p['id'] ?> - <?= htmlspecialchars($p['title']) ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <button class="btn btn-success mt-auto text-dark fw-bold">Gán Code Vào Lớp</button>
        </form>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>