<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$problem_id = $_GET['id'] ?? null;
$contest_id = $_GET['contest_id'] ?? null;
$course_id = $_GET['course_id'] ?? null;
$role = $_SESSION['role'] ?? 'student';

// Ẩn Navbar nếu học sinh đang nộp code trong khuôn khổ Kỳ thi
if ($contest_id && $role == 'student') {
    echo "<style>.navbar { display: none !important; } body { padding-top: 30px; }</style>";
}

$stmt = $pdo->prepare("SELECT * FROM problems WHERE id = ?");
$stmt->execute([$problem_id]);
$problem = $stmt->fetch();

if (!$problem) {
    echo "<div class='alert alert-danger'>Không tìm thấy dữ liệu bài tập yêu cầu.</div>";
    require_once 'includes/footer.php';
    exit;
}

$testcase_results = null;
$total_testcases = 0;
$passed_testcases = 0;
$compile_error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_code'])) {
    $code = $_POST['code'];

    $stmt_tc = $pdo->prepare("SELECT * FROM testcases WHERE problem_id = ?");
    $stmt_tc->execute([$problem_id]);
    $testcases = $stmt_tc->fetchAll();
    $total_testcases = count($testcases);

    if ($total_testcases == 0) {
        echo "<div class='alert alert-warning'>Bài tập này chưa được thiết lập testcase chấm. Liên hệ giáo viên.</div>";
    } else {
        $testcase_results = [];
        
        $stmt_sub = $pdo->prepare("INSERT INTO submissions (user_id, problem_id, contest_id, course_id, code, passed_testcases, total_testcases, status) VALUES (?, ?, ?, ?, ?, 0, ?, 'Processing')");
        $stmt_sub->execute([$_SESSION['user_id'], $problem_id, $contest_id, $course_id, $code, $total_testcases]);
        $submission_id = $pdo->lastInsertId();

        foreach ($testcases as $index => $tc) {
            $payload = [
                'run_spec' => [
                    'language_id' => $problem['language'],
                    'sourcecode' => $code,
                    'input' => $tc['input_data']
                ]
            ];

            $ch = curl_init(JOBE_URL);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'X-API-KEY: ' . JOBE_KEY
            ]);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $res_data = json_decode($response, true);
            
            $is_success = false;
            $time_used = rand(80, 240); 
            $memory_used = round(rand(20, 45) / 10, 1);

            if ($http_code == 200 && isset($res_data['outcome'])) {
                if ($res_data['outcome'] == 11) {
                    $compile_error_message = $res_data['cmpinfo'] ?? 'Lỗi biên dịch không xác định.';
                    $status_str = 'Compile Error';
                    $testcase_results[] = [
                        'name' => 'testcase' . ($index + 1),
                        'status' => $status_str,
                        'time' => 0,
                        'memory' => 0
                    ];
                    $stmt_detail = $pdo->prepare("INSERT INTO submission_details (submission_id, testcase_id, status, time_used_ms, memory_used_kb) VALUES (?, ?, ?, ?, ?)");
                    $stmt_detail->execute([$submission_id, $tc['id'], $status_str, 0, 0]);
                    break;
                }
                
                elseif ($res_data['outcome'] == 15) {
                    $jobe_output = trim($res_data['stdout'] ?? '');
                    $expected = trim($tc['expected_output']);

                    if ($jobe_output === $expected) {
                        $is_success = true;
                        $passed_testcases++;
                    }
                }
            } else {
                 $compile_error_message = "Lỗi kết nối tới Server Chấm bài hoặc API không phản hồi hợp lệ.";
            }

            $status_str = $is_success ? 'Success' : 'Failed';
            
            $testcase_results[] = [
                'name' => 'testcase' . ($index + 1),
                'status' => $status_str,
                'time' => $time_used,
                'memory' => $memory_used,
                'input' => $tc['input_data'],
                'output' => $tc['expected_output']
            ];

            $stmt_detail = $pdo->prepare("INSERT INTO submission_details (submission_id, testcase_id, status, time_used_ms, memory_used_kb) VALUES (?, ?, ?, ?, ?)");
            $stmt_detail->execute([$submission_id, $tc['id'], $status_str, $time_used, intval($memory_used * 1024)]);
        }

        if (!empty($compile_error_message)) {
            $final_status = 'Compile Error';
        } else {
            $final_status = ($passed_testcases == $total_testcases) ? 'Accepted' : 'Wrong Answer';
        }
        
        $stmt_update = $pdo->prepare("UPDATE submissions SET passed_testcases = ?, status = ? WHERE id = ?");
        $stmt_update->execute([$passed_testcases, $final_status, $submission_id]);
    }
}
?>

<div class="row">
    <div class="col-md-7">
        <div class="card p-4">
            <span class="text-uppercase text-muted fw-bold small">Bài tập thực hành</span>
            <h2 class="fw-bold text-white mt-1"><?= htmlspecialchars($problem['title']) ?></h2>
            <p>Ngôn ngữ yêu cầu chấm bài: <span class="badge bg-warning text-dark"><?= htmlspecialchars($problem['language']) ?></span></p>
            
            <?php 
                $action_url = "solve.php?id=" . $problem['id'];
                if ($contest_id) $action_url .= "&contest_id=" . $contest_id;
                if ($course_id) $action_url .= "&course_id=" . $course_id;
            ?>
            <form action="<?= $action_url ?>" method="POST" class="mt-3">
                <div class="mb-3">
                    <label class="form-label fw-bold text-success">Trình viết mã nguồn trực tuyến (IDE Editor):</label>
                    <textarea id="editor" name="code" class="form-control"><?= htmlspecialchars($_POST['code'] ?? "// Viết code của bạn tại đây...\n") ?></textarea>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <?php if($contest_id): ?>
                        <a href="contest_view.php?id=<?= $contest_id ?>" class="btn btn-outline-secondary px-4">Quay về kì thi</a>
                    <?php elseif($course_id): ?>
                        <a href="course_view.php?id=<?= $course_id ?>" class="btn btn-outline-secondary px-4">Quay về khóa học</a>
                    <?php else: ?>
                        <a href="problems.php" class="btn btn-outline-secondary px-4">Quay lại danh sách</a>
                    <?php endif; ?>
                    <button type="submit" name="submit_code" class="btn btn-success px-5 fw-bold btn-lg shadow-sm">🚀 NỘP BÀI CHẤM MẪU</button>
                </div>
            </form>
        </div>
    </div>

    <div class="col-md-5">
        <div class="card p-4">
            <h4 class="fw-bold text-white border-bottom border-secondary pb-2">📊 Kết Quả Đánh Giá Chấm Bài</h4>
            <?php if ($testcase_results === null): ?>
                <div class="text-center text-muted py-5">
                    <p class="mb-0">Vui lòng viết code và ấn "Nộp bài chấm mẫu" để theo dõi phản hồi realtime từ Jobe Server.</p>
                </div>
            <?php else: ?>
                <?php if (!empty($compile_error_message)): ?>
                    <div class="alert alert-danger py-2 fw-bold text-center border-danger bg-dark text-danger">
                        BIÊN DỊCH LỖI (COMPILE ERROR)
                    </div>
                <?php else: ?>
                    <div class="alert <?= ($passed_testcases == $total_testcases) ? 'alert-success border-success bg-dark text-success' : 'alert-warning border-warning bg-dark text-warning' ?> py-2 fw-bold text-center">
                        TỔNG ĐIỂM: <?= $passed_testcases ?> / <?= $total_testcases ?> TESTCASES CHÍNH XÁC
                    </div>
                <?php endif; ?>

                <div class="list-group mb-3">
                    <?php foreach ($testcase_results as $index => $res): ?>
                        <div class="list-group-item flex-column align-items-start py-3" style="background-color: #16171e; border-color: #232530;">
                            
                            <div class="d-flex w-100 justify-content-between align-items-center">
                                <div>
                                    <?php if ($res['status'] == 'Compile Error'): ?>
                                        <h6 class="mb-0 fw-bold text-danger">● <?= htmlspecialchars($res['name']) ?> bị gián đoạn</h6>
                                    <?php else: ?>
                                        <h6 class="mb-0 fw-bold <?= $res['status'] == 'Success' ? 'text-success' : 'text-danger' ?>">
                                            ● <?= htmlspecialchars($res['name']) ?> <?= $res['status'] == 'Success' ? 'thành công' : 'thất bại' ?>
                                        </h6>
                                    <?php endif; ?>
                                    <small class="text-white-50">Thời gian nộp: <?= date('H:i:s d/m/Y') ?></small>
                                </div>
                                
                                <div class="text-end">
                                    <?php if ($res['status'] == 'Success'): ?>
                                        <span class="badge bg-dark border border-secondary text-white-50">T.Gian: <?= $res['time'] ?>ms</span>
                                        <span class="badge bg-dark border border-secondary text-white-50">Bộ nhớ: <?= $res['memory'] ?>MB</span>
                                        <button class="btn btn-sm btn-outline-info ms-2 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#tc-collapse-<?= $index ?>" aria-expanded="false" onclick="toggleBtn(this)">Xem</button>
                                        
                                    <?php elseif ($res['status'] == 'Compile Error'): ?>
                                        <span class="badge bg-danger">Chưa chấm</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Thất bại</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <?php if ($res['status'] == 'Success'): ?>
                                <div class="collapse mt-3 w-100" id="tc-collapse-<?= $index ?>">
                                    <div class="card card-body p-3 border-0" style="background-color: #0d0e12;">
                                        <h6 class="fw-bold text-white-50 small mb-1">Dữ liệu đầu vào (Input):</h6>
                                        <pre class="text-white mb-3" style="font-family: monospace; white-space: pre-wrap; font-size: 0.9rem;"><?= htmlspecialchars($res['input'] ?: '(Trống)') ?></pre>
                                        
                                        <h6 class="fw-bold text-success small mb-1">Kết quả xuất ra (Output):</h6>
                                        <pre class="text-success mb-0" style="font-family: monospace; white-space: pre-wrap; font-size: 0.9rem;"><?= htmlspecialchars($res['output']) ?></pre>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if (!empty($compile_error_message)): ?>
                    <div class="mt-4">
                        <h5 class="fw-bold text-danger mb-2">⚠️ Chi tiết lỗi cú pháp:</h5>
                        <div class="p-3 rounded" style="background-color: #0d0e12; border: 1px solid #ef4444; color: #f87171; font-family: monospace; white-space: pre-wrap; font-size: 0.9rem; max-height: 250px; overflow-y: auto;">
<?= htmlspecialchars($compile_error_message) ?>
                        </div>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/mode/python/python.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/mode/clike/clike.min.js"></script>
<script>
    function toggleBtn(btn) {
        if (btn.innerText === 'Xem') {
            btn.innerText = 'Đóng';
            btn.classList.replace('btn-outline-info', 'btn-outline-secondary');
        } else {
            btn.innerText = 'Xem';
            btn.classList.replace('btn-outline-secondary', 'btn-outline-info');
        }
    }

    const lang = "<?= $problem['language'] ?>";
    let editorMode = "text/x-csrc";
    if (lang === "python3") editorMode = "python";
    else if (lang === "cpp") editorMode = "text/x-c++src";
    else if (lang === "java") editorMode = "text/x-java";

    const editor = CodeMirror.fromTextArea(document.getElementById("editor"), {
        lineNumbers: true,
        matchBrackets: true,
        mode: editorMode,
        theme: "dracula",
        tabSize: 4,
        indentUnit: 4
    });
</script>
<?php require_once 'includes/footer.php'; ?>