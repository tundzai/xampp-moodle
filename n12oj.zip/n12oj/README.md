# N12OJ - Hệ thống đánh giá kết quả lập trình LMS

## 1. 📖 Mô tả dự án
**N12OJ** là một nền tảng giáo dục toàn diện, kết hợp giữa Hệ thống Quản lý Học tập (LMS) và Hệ thống Chấm điểm Mã nguồn tự động (Online Judge). Dự án được thiết kế hướng tới việc tối ưu hóa trải nghiệm giảng dạy và học tập lập trình. Đặc biệt, hệ thống được tích hợp tiêu chuẩn bảo mật cao thông qua **Safe Exam Browser (SEB)**, đảm bảo tính công bằng và nghiêm ngặt tuyệt đối trong các kỳ thi trực tuyến.

**Tác giả:** Phạm Đăng Toàn - Đại học Bách Khoa Hà Nội (HUST).

---

## 2. ✨ Tính năng chính

### 👨‍🎓 Đối với Học sinh (Student):
- **Khóa học LMS:** Truy cập bài giảng, video, tài liệu do giáo viên cung cấp.
- **Thực hành Code:** Làm bài tập lập trình (Python, C++, Java) với IDE trực tuyến và nhận phản hồi chấm điểm (Testcase) ngay lập tức.
- **Bài trắc nghiệm (Quiz):** Làm bài kiểm tra lý thuyết, lưu nháp tiến độ và xem điểm.
- **Kỳ thi bảo mật (SEB):** Tham gia các kỳ thi nghiêm ngặt (chặn Navbar, chặn thoát, bắt buộc dùng phần mềm Safe Exam Browser).

### 👨‍🏫 Đối với Giáo viên (Teacher):
- **Quản lý Lớp học:** Tạo khóa học mới, duyệt học sinh, thêm tài liệu (URL/Drive/YouTube).
- **Ngân hàng đề:** Tạo bài tập Code (thiết lập Testcase) và tạo bộ câu hỏi Trắc nghiệm.
- **Tổ chức Kỳ thi:** Thiết lập kỳ thi, giới hạn thời gian, nhúng file cấu hình `.seb`.
- **Chấm điểm & Thống kê:** Theo dõi tiến độ học tập, xem dashboard thống kê lỗi sai của học sinh và quản lý bài nộp.

### 🛡️ Đối với Quản trị viên (Admin):
- **Quản lý Tài khoản:** Phân quyền (Admin/Teacher/Student), cấp lại mật khẩu.
- Toàn quyền chỉnh sửa, xóa khóa học, kỳ thi, bài tập và bài nộp trên toàn hệ thống.

---

## 3. 🛠️ Công nghệ sử dụng
- **Frontend:** HTML5, CSS3 (Custom Global CSS với font Inter), Bootstrap 5, JS thuần.
- **Code Editor:** CodeMirror (Theme Dracula, hỗ trợ syntax highlighting).
- **Backend:** PHP 7.x / 8.x (Thuần/Core).
- **Cơ sở dữ liệu:** MySQL (sử dụng PDO để chống SQL Injection).
- **API & Chấm bài:** Tích hợp RESTful API với **Jobe Server** để biên dịch và chạy code cách ly (Sandbox).
- **Bảo mật thi cử:** Tích hợp giao thức `seb://` của **Safe Exam Browser**.

---

## 4. 📐 Kiến trúc hệ thống
Hệ thống hoạt động theo mô hình Client-Server:
1. **Client Layer:** Trình duyệt web hoặc Safe Exam Browser render giao diện người dùng.
2. **Application Layer (PHP):** Xử lý logic phân quyền, tính toán thời gian, quản lý luồng dữ liệu (CRUD).
3. **Database Layer (MySQL):** Lưu trữ thông tin người dùng, đề bài, testcase, điểm số và trạng thái khóa học.
4. **Execution Layer (Jobe API):** PHP Server gửi mã nguồn và input của học sinh qua dạng JSON POST request đến Jobe Server. Jobe Server chạy code trong Sandbox và trả về Output/Memory/Time cho PHP Server xử lý.

---

## 5. 🚀 Hướng dẫn cài đặt

### Yêu cầu môi trường:
- XAMPP / MAMP / LAMP (PHP >= 7.4, MySQL >= 5.7).
- Một Jobe Server đang hoạt động (có thể tự host hoặc dùng Jobe server công cộng có API Key).

### Các bước triển khai:
1. **Clone dự án** vào thư mục `htdocs` (nếu dùng XAMPP). Ví dụ: `htdocs/online_judge/`.
2. **Tạo CSDL:** Mở phpMyAdmin, tạo database tên `online_judge`.
3. **Import SQL:** Chạy lần lượt các file SQL trong thư mục `database_sql/` (Bảng gốc -> Quiz -> LMS -> SEB -> Status).
4. **Cấu hình hệ thống:** Mở file `config/db.php`:
   - Cập nhật thông tin kết nối DB (`DB_USER`, `DB_PASS`).
   - Cập nhật `JOBE_URL` và `JOBE_KEY`.
5. **Cấu hình SEB:** Đảm bảo thư mục `uploads/seb_configs/` tồn tại và có quyền ghi (CHMOD 777).

---

## 6. 📁 Cấu trúc thư mục

```text
online_judge/
├── config/                 # Cấu hình kết nối DB & API Jobe
├── includes/               # CSS toàn cục, Navbar, Footer
├── uploads/seb_configs/    # Chứa file cấu hình Safe Exam Browser (.seb)
├── online_judge_sql/           # Chứa các file Script khởi tạo CSDL
├── index.php               # Trang chủ
├── login.php, logout.php...# Module Tài khoản & Phân quyền
├── courses.php, course_... # Module Quản lý Khóa học (LMS)
├── problems.php, solve.php # Module Bài tập & Trình biên dịch Code trực tuyến
├── contests.php, contest_..# Module Kỳ thi (Có tích hợp Gateway SEB)
└── quizzes.php, take_quiz..# Module Bài tập Trắc nghiệm
```

---

## 7. 💡 Hướng dẫn sử dụng
1. **Đăng ký/Đăng nhập:** Mặc định tài khoản tạo mới có quyền `student`. Truy cập DB sửa cột `role` thành `admin` cho tài khoản của bạn.
2. **Tạo kỳ thi SEB:** Đăng nhập Admin -> Chuyển đến phần "Kỳ thi" -> Thiết lập kỳ thi -> Upload file `.seb` (tạo bằng SEB Configuration Tool với URL là trang login của web).
3. **Môi trường thi:** Học sinh khi dùng Chrome sẽ bị chặn ở cổng SEB. Sau khi cài app và tải file cấu hình, bấm nút "Chạy cấu hình" để phần mềm tự động bật lên và mở khóa đề thi.

---

## 8. 🔌 Tích hợp API (Jobe Server)
Hệ thống sử dụng REST API giao tiếp với trình biên dịch.
- **Endpoint:** `POST {JOBE_URL}/runs`
- **Headers:** `Content-Type: application/json`, `X-API-KEY: {key}`
- **Payload:** ```json
  {
    "run_spec": {
      "language_id": "python3",
      "sourcecode": "print('Hello')",
      "input": "..."
    }
  }
  ```

---

## 9. 🔮 Hướng phát triển tương lai
- Thêm tính năng lưu và phát lại lịch sử gõ code (Keystroke logging) để chống copy-paste.
- Tích hợp biểu đồ Analytics chi tiết hơn cho từng học sinh.
- Hỗ trợ thêm nhiều ngôn ngữ lập trình (Go, Rust).
- Tích hợp AI để gợi ý sửa lỗi (Compile Error) cho học sinh dựa trên code đã nộp.
