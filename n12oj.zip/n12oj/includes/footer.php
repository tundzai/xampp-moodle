</div>
<footer class="footer mt-auto py-3 bg-light text-center border-top">
    <div class="container">
        <span class="text-muted">&copy; 2026 N12OJ.</span>
    </div>
</footer>
<!-- Bootstrap 5 JS CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>