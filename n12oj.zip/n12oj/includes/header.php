<?php
require_once __DIR__ . '/../config/db.php';
if (isset($_SESSION['user_id']) && $_SESSION['require_change'] == 1 && basename($_SERVER['PHP_SELF']) != 'change_password.php' && basename($_SERVER['PHP_SELF']) != 'logout.php') {
    header("Location: change_password.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hệ thống N12OJ</title>
    <link rel="icon" href="imgs/icon.ico">
    <link rel="shortcut icon" href="imgs/icon.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/theme/dracula.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* QUY TẮC THIẾT KẾ TOÀN CỤC (DESIGN SYSTEM) */
        :root {
            --bg-main: #0b0f19;         /* Đen nhám sâu - Dịu mắt */
            --bg-surface: #111827;      /* Đen xám cho các khối (Card) */
            --bg-surface-hover: #1f2937;
            --border-color: #1f2937;    /* Viền mỏng tinh tế */
            
            --text-main: #f9fafb;       /* Trắng sáng (Tiêu đề) */
            --text-muted: #9ca3af;      /* Xám bạc (Đoạn văn, chú thích) */
            
            --accent-primary: #3b82f6;  /* Xanh dương (Mặc định/Nút chính) */
            --accent-success: #10b981;  /* Xanh lá (Hoàn thành/Đúng) */
            --accent-warning: #f59e0b;  /* Vàng/Cam (Đang xử lý/Cảnh báo) */
            --accent-danger: #ef4444;   /* Đỏ (Lỗi/Xóa/Thoát) */
            --accent-purple: #8b5cf6;   /* Tím (Khóa học/Premium) */
            
            --radius-md: 12px;
            --radius-lg: 16px;
        }

        body { 
            background-color: var(--bg-main) !important; 
            color: var(--text-main) !important; 
            font-family: 'Inter', sans-serif !important; 
            letter-spacing: 0.3px; 
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* NAVBAR HIỆN ĐẠI */
        .navbar { 
            background-color: rgba(17, 24, 39, 0.8) !important; 
            backdrop-filter: blur(10px); /* Hiệu ứng kính mờ (Glassmorphism) */
            border-bottom: 1px solid var(--border-color) !important; 
            padding: 15px 0;
            margin-bottom: 40px; 
            position: sticky; top: 0; z-index: 1000;
        }
        .navbar-brand { font-size: 1.5rem; font-weight: 800; letter-spacing: 1px; color: var(--text-main) !important; }
        .nav-link { font-weight: 500; color: var(--text-muted) !important; transition: all 0.2s; margin: 0 5px; }
        .nav-link:hover, .nav-link.active { color: var(--text-main) !important; transform: translateY(-1px); }

        /* KHỐI (CARDS) - TỐI GIẢN, ĐỔ BÓNG MỀM MẠI */
        .card { 
            background-color: var(--bg-surface) !important; 
            border: 1px solid var(--border-color) !important; 
            border-radius: var(--radius-md); 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -1px rgba(0, 0, 0, 0.2); 
            transition: all 0.3s ease;
        }
        .card:hover { border-color: #374151 !important; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.4); }

        /* BẢNG DỮ LIỆU (TABLES) */
        .table { color: var(--text-main) !important; border-color: var(--border-color) !important; vertical-align: middle; }
        .table-dark { --bs-table-bg: var(--bg-surface); color: var(--text-main); }
        .table-dark th { background-color: #0d1117; color: var(--text-muted); font-weight: 600; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.5px; padding: 15px; border-bottom: 2px solid var(--border-color); }
        .table-dark td { padding: 15px; border-bottom: 1px solid var(--border-color); }
        .table-hover>tbody>tr:hover>* { --bs-table-accent-bg: var(--bg-surface-hover) !important; color: var(--text-main); cursor: default; }

        /* NÚT BẤM (BUTTONS) - BO GÓC, KHÔNG VIỀN GẮT */
        .btn { border-radius: 8px; font-weight: 600; padding: 10px 20px; transition: all 0.2s ease; letter-spacing: 0.3px; border: none; }
        .btn-sm { padding: 6px 12px; font-size: 0.875rem; }
        .btn-primary, .btn-info { background-color: var(--accent-primary) !important; color: #fff !important; }
        .btn-primary:hover, .btn-info:hover { background-color: #2563eb !important; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4); }
        .btn-success { background-color: var(--accent-success) !important; color: #fff !important; }
        .btn-success:hover { background-color: #059669 !important; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4); }
        .btn-warning { background-color: var(--accent-warning) !important; color: #111827 !important; }
        .btn-warning:hover { background-color: #d97706 !important; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4); }
        .btn-danger { background-color: var(--accent-danger) !important; color: #fff !important; }
        .btn-danger:hover { background-color: #dc2626 !important; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4); }
        
        .btn-outline-secondary { border: 1px solid var(--border-color) !important; color: var(--text-muted) !important; background: transparent; }
        .btn-outline-secondary:hover { background-color: var(--border-color) !important; color: var(--text-main) !important; }

        /* FORM VÀ INPUT */
        .form-control, .form-select { 
            background-color: #030712 !important; 
            border: 1px solid var(--border-color) !important; 
            color: var(--text-main) !important; 
            border-radius: 8px; padding: 12px 16px; font-size: 0.95rem; 
        }
        .form-control:focus, .form-select:focus { 
            border-color: var(--accent-primary) !important; 
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2) !important; 
        }
        .form-label { font-weight: 600; color: var(--text-muted); font-size: 0.9rem; margin-bottom: 8px; }

        /* BADGES (THẺ TRẠNG THÁI) */
        .badge { padding: 6px 10px; border-radius: 6px; font-weight: 600; font-size: 0.75rem; letter-spacing: 0.5px; }
        .bg-success { background-color: rgba(16, 185, 129, 0.15) !important; color: var(--accent-success) !important; border: 1px solid rgba(16, 185, 129, 0.3); }
        .bg-danger { background-color: rgba(239, 68, 68, 0.15) !important; color: var(--accent-danger) !important; border: 1px solid rgba(239, 68, 68, 0.3); }
        .bg-warning { background-color: rgba(245, 158, 11, 0.15) !important; color: var(--accent-warning) !important; border: 1px solid rgba(245, 158, 11, 0.3); }
        .bg-info { background-color: rgba(59, 130, 246, 0.15) !important; color: var(--accent-primary) !important; border: 1px solid rgba(59, 130, 246, 0.3); }
        .bg-secondary { background-color: rgba(156, 163, 175, 0.15) !important; color: var(--text-muted) !important; border: 1px solid rgba(156, 163, 175, 0.3); }

        /* IDE CODEMIRROR CUSTOM */
        .CodeMirror { height: 450px; border-radius: 8px; border: 1px solid var(--border-color) !important; font-family: 'Fira Code', Consolas, monospace; font-size: 15px; }
        
        /* THANH CUỘN (SCROLLBAR) HIỆN ĐẠI */
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg-main); }
        ::-webkit-scrollbar-thumb { background: #374151; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #4b5563; }

        /* CHỮ & TIÊU ĐỀ */
        h1, h2, h3, h4, h5, h6 { font-weight: 700; color: var(--text-main); letter-spacing: -0.5px; }
        .text-muted { color: var(--text-muted) !important; }
        .text-info { color: var(--accent-primary) !important; }
        .text-success { color: var(--accent-success) !important; }
        .text-warning { color: var(--accent-warning) !important; }
        .text-danger { color: var(--accent-danger) !important; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
            <img src="imgs/logo.png" alt="N12OJ" class="me-2" style="height:32px; width:auto; display:inline-block;">
            <span style="color: var(--accent-primary);">N12OJ</span>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto ps-3">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item"><a class="nav-link" href="courses.php">Khóa Học LMS</a></li>
                    <li class="nav-item"><a class="nav-link" href="problems.php">Bài tập</a></li>
                    <li class="nav-item"><a class="nav-link" href="contests.php">Kỳ thi</a></li>
                    <li class="nav-item"><a class="nav-link" href="quizzes.php">Trắc Nghiệm</a></li>
                    <li class="nav-item"><a class="nav-link" href="submissions.php">Lịch sử nộp</a></li>
                    
                    <?php if ($_SESSION['role'] == 'teacher' || $_SESSION['role'] == 'admin'): ?>
                        <li class="nav-item dropdown ms-2">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" style="color: var(--accent-warning) !important;">
                                ⚙️ Quản lý 
                            </a>
                            <ul class="dropdown-menu dropdown-menu-dark" style="background-color: var(--bg-surface); border: 1px solid var(--border-color); border-radius: 8px;">
                                <li><a class="dropdown-item py-2" href="create_problem.php">📝 Tạo bài Code mới</a></li>
                                <li><a class="dropdown-item py-2" href="create_contest.php">🏆 Thiết lập Kỳ thi</a></li>
                                <li><a class="dropdown-item py-2" href="create_quiz.php">📋 Soạn Trắc nghiệm</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    
                    <?php if ($_SESSION['role'] == 'admin'): ?>
                        <li class="nav-item"><a class="nav-link ms-2" href="users_list.php" style="color: var(--accent-danger) !important; font-weight: 600;">🛡️ Quản trị </a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ms-auto align-items-center">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="d-flex align-items-center me-3 px-3 py-1 rounded-pill" style="background-color: rgba(255,255,255,0.05); border: 1px solid var(--border-color);">
                        <span class="text-muted small me-2">Xin chào,</span>
                        <strong class="text-white me-2"><?= htmlspecialchars($_SESSION['email']) ?></strong> 
                        <?php if($_SESSION['role'] == 'admin'): ?>
                            <span class="badge bg-danger">Admin</span>
                        <?php elseif($_SESSION['role'] == 'teacher'): ?>
                            <span class="badge bg-warning">Giáo viên</span>
                        <?php else: ?>
                            <span class="badge bg-info">Học sinh</span>
                        <?php endif; ?>
                    </div>
                    <li class="nav-item"><a class="btn btn-outline-secondary btn-sm fw-bold" href="logout.php">Đăng xuất</a></li>
                <?php else: ?>
                    <li class="nav-item me-2"><a class="nav-link" href="login.php">Đăng nhập</a></li>
                    <li class="nav-item"><a class="btn btn-primary btn-sm px-4" href="register.php">Đăng ký ngay</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container mb-5">