<?php
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) exit('Unauthorized');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $attempt_id = $_POST['attempt_id'];
    $question_id = $_POST['question_id'];
    $option_ids = json_decode($_POST['option_ids'], true);

    try {
        $pdo->beginTransaction();
        // Xóa các lựa chọn cũ của câu hỏi này
        $stmt_del = $pdo->prepare("DELETE FROM attempt_answers WHERE attempt_id = ? AND question_id = ?");
        $stmt_del->execute([$attempt_id, $question_id]);

        // Insert lựa chọn mới
        if (is_array($option_ids) && count($option_ids) > 0) {
            $stmt_ins = $pdo->prepare("INSERT INTO attempt_answers (attempt_id, question_id, option_id) VALUES (?, ?, ?)");
            foreach ($option_ids as $o_id) {
                $stmt_ins->execute([$attempt_id, $question_id, $o_id]);
            }
        }
        $pdo->commit();
        echo "OK";
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Error";
    }
}
?>