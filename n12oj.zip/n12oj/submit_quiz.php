<?php
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$attempt_id = $_REQUEST['attempt_id'] ?? 0;

// Lấy thông tin attempt
$stmt = $pdo->prepare("SELECT * FROM quiz_attempts WHERE id = ? AND user_id = ?");
$stmt->execute([$attempt_id, $_SESSION['user_id']]);
$attempt = $stmt->fetch();

if (!$attempt) die("Invalid Attempt");
if ($attempt['status'] == 'completed') {
    header("Location: quiz_result.php?attempt_id=$attempt_id"); exit;
}

// Lấy toàn bộ câu hỏi của Quiz này
$quiz_id = $attempt['quiz_id'];
$stmt_q = $pdo->prepare("SELECT id FROM questions WHERE quiz_id = ?"); $stmt_q->execute([$quiz_id]);
$questions = $stmt_q->fetchAll(PDO::FETCH_COLUMN);

// Chấm điểm theo chuẩn 1A: Mọi đáp án chọn phải hoàn toàn khớp với Database
$score = 0;

// Vì dữ liệu đã lưu nháp trong bảng attempt_answers nhờ AJAX (hoặc submit form thường), ta lấy từ DB ra để chấm
// Đề phòng trường hợp submit form thường (JS disable), ta cập nhật lại bảng attempt_answers từ POST data trước
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['answers'])) {
    $pdo->prepare("DELETE FROM attempt_answers WHERE attempt_id = ?")->execute([$attempt_id]);
    $stmt_ins = $pdo->prepare("INSERT INTO attempt_answers (attempt_id, question_id, option_id) VALUES (?, ?, ?)");
    foreach ($_POST['answers'] as $qId => $optIds) {
        foreach ($optIds as $oId) { $stmt_ins->execute([$attempt_id, $qId, $oId]); }
    }
}

// Bắt đầu chấm
foreach ($questions as $qId) {
    // 1. Lấy mảng ID đáp án ĐÚNG từ DB
    $stmt_corr = $pdo->prepare("SELECT id FROM options WHERE question_id = ? AND is_correct = 1 ORDER BY id ASC");
    $stmt_corr->execute([$qId]);
    $correct_opts = $stmt_corr->fetchAll(PDO::FETCH_COLUMN);

    // 2. Lấy mảng ID đáp án USER CHỌN
    $stmt_user = $pdo->prepare("SELECT option_id FROM attempt_answers WHERE attempt_id = ? AND question_id = ? ORDER BY option_id ASC");
    $stmt_user->execute([$attempt_id, $qId]);
    $user_opts = $stmt_user->fetchAll(PDO::FETCH_COLUMN);

    // So sánh 2 mảng (Cần giống hệt nhau về giá trị và số lượng)
    if ($correct_opts == $user_opts) {
        $score++;
    }
}

// Cập nhật CSDL
$current_time_str = date('Y-m-d H:i:s');
$stmt_upd = $pdo->prepare("UPDATE quiz_attempts SET score = ?, status = 'completed', submitted_at = ? WHERE id = ?");
$stmt_upd->execute([$score, $current_time_str, $attempt_id]);

header("Location: quiz_result.php?attempt_id=$attempt_id");
exit;
?>