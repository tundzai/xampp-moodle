-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 25, 2026 lúc 10:39 PM
-- Phiên bản máy phục vụ: 11.8.6-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `online_judge`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `attempt_answers`
--

CREATE TABLE `attempt_answers` (
  `attempt_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `attempt_answers`
--

INSERT INTO `attempt_answers` (`attempt_id`, `question_id`, `option_id`) VALUES
(1, 1, 3),
(2, 1, 3),
(3, 1, 2),
(1, 2, 6),
(2, 2, 6),
(3, 2, 5),
(1, 3, 12),
(2, 3, 12),
(3, 3, 9),
(1, 4, 14),
(2, 4, 13),
(3, 4, 13),
(1, 5, 19),
(2, 5, 18),
(3, 5, 17);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `contests`
--

CREATE TABLE `contests` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `seb_config_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `contests`
--

INSERT INTO `contests` (`id`, `title`, `start_time`, `end_time`, `seb_config_path`, `created_at`) VALUES
(1, 'kiểm tra lập trình', '2026-06-23 17:58:00', '2026-06-23 18:00:00', NULL, '2026-06-23 10:57:52'),
(2, 'luyện tập', '2026-06-23 18:10:00', '2026-06-23 18:15:00', NULL, '2026-06-23 11:09:37'),
(3, 'TEST', '2026-06-25 15:35:00', '2026-06-25 15:45:00', NULL, '2026-06-25 08:32:37'),
(4, '123', '2026-06-25 15:53:00', '2026-06-25 15:55:00', NULL, '2026-06-25 08:53:01'),
(5, '234', '2026-06-25 15:57:00', '2026-06-25 16:00:00', NULL, '2026-06-25 08:57:05'),
(6, 'fhjfgh', '2026-06-25 17:09:00', '2026-06-25 18:09:00', NULL, '2026-06-25 10:08:22'),
(7, 'qưe', '2026-06-25 18:15:00', '2026-06-25 19:20:00', NULL, '2026-06-25 11:14:53'),
(8, 'tdc', '2026-06-25 18:51:00', '2026-06-25 19:51:00', 'uploads/seb_configs/1782388299_config1.seb', '2026-06-25 11:51:39'),
(9, '555', '2026-06-25 20:32:00', '2026-06-25 21:32:00', NULL, '2026-06-25 13:32:12'),
(13, 'ih', '2026-06-25 20:56:00', '2026-06-25 21:56:00', 'uploads/seb_configs/1782395788_config2.seb', '2026-06-25 13:56:28');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `contest_problems`
--

CREATE TABLE `contest_problems` (
  `contest_id` int(11) NOT NULL,
  `problem_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `contest_problems`
--

INSERT INTO `contest_problems` (`contest_id`, `problem_id`) VALUES
(2, 1),
(3, 1),
(4, 2),
(5, 2),
(6, 2),
(7, 2),
(8, 2),
(1, 3),
(4, 3),
(9, 3),
(13, 3),
(4, 4),
(5, 4),
(6, 4),
(7, 4),
(8, 4),
(9, 5),
(13, 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `contest_status`
--

CREATE TABLE `contest_status` (
  `user_id` int(11) NOT NULL,
  `contest_id` int(11) NOT NULL,
  `is_finished` tinyint(1) DEFAULT 0,
  `finished_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `contest_status`
--

INSERT INTO `contest_status` (`user_id`, `contest_id`, `is_finished`, `finished_at`) VALUES
(2, 13, 1, '2026-06-25 14:02:46');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `teacher_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `courses`
--

INSERT INTO `courses` (`id`, `title`, `description`, `teacher_id`, `created_at`) VALUES
(1, 'Abc', 'luyện tập', 1, '2026-06-25 09:59:58'),
(2, 'yuo', 'sdf', 3, '2026-06-25 10:09:14');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `course_enrollments`
--

CREATE TABLE `course_enrollments` (
  `course_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `enrolled_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `course_enrollments`
--

INSERT INTO `course_enrollments` (`course_id`, `user_id`, `enrolled_at`) VALUES
(1, 2, '2026-06-25 10:08:40'),
(2, 2, '2026-06-25 10:09:19');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `course_materials`
--

CREATE TABLE `course_materials` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link_url` text NOT NULL,
  `material_type` enum('video','document','other') DEFAULT 'other',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `course_materials`
--

INSERT INTO `course_materials` (`id`, `course_id`, `title`, `link_url`, `material_type`, `created_at`) VALUES
(1, 1, 'Tài liệu học tập', 'https://www.w3schools.com/cpp/default.asp', 'other', '2026-06-25 10:01:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `course_problems`
--

CREATE TABLE `course_problems` (
  `course_id` int(11) NOT NULL,
  `problem_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `course_problems`
--

INSERT INTO `course_problems` (`course_id`, `problem_id`) VALUES
(1, 1),
(2, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `course_quizzes`
--

CREATE TABLE `course_quizzes` (
  `course_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `course_quizzes`
--

INSERT INTO `course_quizzes` (`course_id`, `quiz_id`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `options`
--

INSERT INTO `options` (`id`, `question_id`, `option_text`, `is_correct`) VALUES
(1, 1, 'size()', 0),
(2, 1, 'length()', 0),
(3, 1, 'len()', 1),
(4, 1, 'count()', 0),
(5, 2, 'int (Số nguyên)', 0),
(6, 2, 'float (Số thực)', 1),
(7, 2, 'str (Chuỗi)', 0),
(8, 2, 'bool (Boolean)', 0),
(9, 3, 'List (Danh sách)', 0),
(10, 3, 'Tuple (Tuple)', 0),
(11, 3, 'Set (Tập hợp)', 0),
(12, 3, 'Dictionary (Từ điển)', 1),
(13, 4, 'for i in range(5):', 1),
(14, 4, 'for i in range(1, 5):', 0),
(15, 4, 'for i to 4:', 0),
(16, 4, 'loop i from 0 to 4:', 0),
(17, 5, 'func', 0),
(18, 5, 'def', 1),
(19, 5, 'function', 0),
(20, 5, 'define', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `problems`
--

CREATE TABLE `problems` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `language` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `problems`
--

INSERT INTO `problems` (`id`, `title`, `language`, `created_at`) VALUES
(1, 'Tính tổng hai số nguyên A và B (Cách nhau bởi dấu cách)', 'cpp', '2026-06-23 10:56:33'),
(2, 'Kiểm tra số chẵn lẻ (In ra Chan hoặc Le)', 'cpp', '2026-06-23 10:56:33'),
(3, 'Tìm số lớn nhất trong 3 số nguyên (A B C)', 'cpp', '2026-06-23 10:56:33'),
(4, 'Tính giai thừa của số tự nhiên N (N!)', 'cpp', '2026-06-23 10:56:33'),
(5, 'Kiểm tra số nguyên tố (In ra YES hoặc NO)', 'cpp', '2026-06-23 10:56:33');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `questions`
--

INSERT INTO `questions` (`id`, `quiz_id`, `question_text`) VALUES
(1, 1, 'Hàm nào sau đây được sử dụng để lấy độ dài của một danh sách (list) trong Python?'),
(2, 1, 'Kiểu dữ liệu của kết quả biểu thức \"3 / 2\" trong Python 3 là gì?'),
(3, 1, 'Cấu trúc dữ liệu nào trong Python sử dụng các cặp \"key: value\" (khóa: giá trị)?'),
(4, 1, 'Làm thế nào để bắt đầu một vòng lặp chạy từ 0 đến 4 trong Python?'),
(5, 1, 'Từ khóa nào được sử dụng để định nghĩa một hàm (function) trong Python?');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `quizzes`
--

CREATE TABLE `quizzes` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `duration_minutes` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `quizzes`
--

INSERT INTO `quizzes` (`id`, `title`, `duration_minutes`, `created_at`) VALUES
(1, 'Câu hỏi trắc nghiệm Python (Bài 2)', 15, '2026-06-24 06:10:44');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `quiz_attempts`
--

CREATE TABLE `quiz_attempts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `score` int(11) DEFAULT 0,
  `total_questions` int(11) DEFAULT 0,
  `status` enum('in_progress','completed') DEFAULT 'in_progress'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `quiz_attempts`
--

INSERT INTO `quiz_attempts` (`id`, `user_id`, `quiz_id`, `course_id`, `start_time`, `end_time`, `submitted_at`, `score`, `total_questions`, `status`) VALUES
(1, 1, 1, NULL, '2026-06-24 13:11:02', '2026-06-24 13:26:02', '2026-06-24 13:12:05', 3, 5, 'completed'),
(2, 2, 1, NULL, '2026-06-24 13:13:41', '2026-06-24 13:28:41', '2026-06-24 13:14:12', 5, 5, 'completed'),
(3, 2, 1, NULL, '2026-06-24 13:14:38', '2026-06-24 13:29:38', '2026-06-24 13:14:48', 1, 5, 'completed'),
(4, 2, 1, NULL, '2026-06-24 13:18:03', '2026-06-24 13:33:03', '2026-06-25 18:26:14', 0, 5, 'completed'),
(5, 1, 1, NULL, '2026-06-25 00:00:36', '2026-06-25 00:15:36', '2026-06-25 21:17:34', 0, 5, 'completed'),
(6, 2, 1, NULL, '2026-06-25 18:26:20', '2026-06-25 18:41:20', '2026-06-25 18:26:27', 0, 5, 'completed'),
(7, 1, 1, NULL, '2026-06-25 21:17:39', '2026-06-25 21:32:39', '2026-06-25 21:17:45', 0, 5, 'completed'),
(8, 1, 1, NULL, '2026-06-25 21:26:45', '2026-06-25 21:41:45', '2026-06-25 21:26:50', 0, 5, 'completed');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `submissions`
--

CREATE TABLE `submissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `problem_id` int(11) NOT NULL,
  `contest_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `code` text NOT NULL,
  `passed_testcases` int(11) DEFAULT 0,
  `total_testcases` int(11) DEFAULT 0,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `submissions`
--

INSERT INTO `submissions` (`id`, `user_id`, `problem_id`, `contest_id`, `course_id`, `code`, `passed_testcases`, `total_testcases`, `status`, `created_at`) VALUES
(1, 1, 3, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,b,c;\r\n    cin>>a>>b>>c;\r\n    cout<<max(a,max(b,c));', 0, 5, 'Wrong Answer', '2026-06-23 11:01:36'),
(2, 1, 3, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,b,c;\r\n    cin>>a>>b>>c;\r\n    cout<<max(a,max(b,c));\r\n}', 5, 5, 'Accepted', '2026-06-23 11:03:00'),
(3, 1, 1, 2, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,bl\r\n        cin>>a>>b;\r\n    cout<<a+b;\r\n}', 0, 5, 'Wrong Answer', '2026-06-23 11:11:33'),
(4, 1, 1, 2, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,b;\r\n        cin>>a>>b;\r\n    cout<<a+b;\r\n}', 5, 5, 'Accepted', '2026-06-23 11:11:45'),
(5, 2, 2, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";\r\n}', 5, 5, 'Accepted', '2026-06-23 11:37:49'),
(6, 1, 3, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int a,b,c;\r\n    cin>>a>>b>>c;\r\n    cout<<max(a,max(b,c));\r\n}\r\n      ', 5, 5, 'Accepted', '2026-06-24 06:06:27'),
(7, 1, 3, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int a,b,c;\r\n    cin>>a>>b>>c;\r\n    cout<<max(a,max(b,c));\r\n}', 5, 5, 'Accepted', '2026-06-24 17:12:04'),
(8, 1, 5, NULL, NULL, '#include<bits/stdc++.h>;\r\nusing namespace std;\r\nbool ktsnt(int x)\r\n{\r\n    int i,n;\r\n    if(x<=1) return 0;\r\n    for(i=2;i*i<=n;i++)\r\n    {\r\n        if (x%i==0) return 0;\r\n        else return 1;\r\n    }\r\n    return 1;\r\n}\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n   	if (ktsnt(n)==1) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 0, 5, 'Compile Error', '2026-06-25 07:47:58'),
(9, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nbool ktsnt(int x)\r\n{\r\n    int i,n;\r\n    if(x<=1) return 0;\r\n    for(i=2;i*i<=n;i++)\r\n    {\r\n        if (x%i==0) return 0;\r\n        else return 1;\r\n    }\r\n    return 1;\r\n}\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n   	if (ktsnt(n)==1) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 0, 5, 'Compile Error', '2026-06-25 07:48:53'),
(10, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nbool ktsnt(int x)\r\n{\r\n    int i,m;\r\n    if(x<=1) return 0;\r\n    for(i=2;i*i<=m;i++)\r\n    {\r\n        if (x%i==0) return 0;\r\n        else return 1;\r\n    }\r\n    return 1;\r\n}\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n   	if (ktsnt(n)==1) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 0, 5, 'Compile Error', '2026-06-25 07:49:17'),
(11, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nbool ktsnt(int x)\r\n{\r\n    int i;\r\n    if(x<=1) return 0;\r\n    for(i=2;i*i<=x;i++)\r\n    {\r\n        if (x%i==0) return 0;\r\n        else return 1;\r\n    }\r\n    return 1;\r\n}\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n   	if (ktsnt(n)==1) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 4, 5, 'Wrong Answer', '2026-06-25 07:49:43'),
(12, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n    if (n<=1) cout<<\"NO\";\r\n    else if (n<=3) cout<<\"YES\";\r\n    else if (n%2==0 || n%3==0) cout<<\"NO\";\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    cout<<\"NO\";\r\n                }\r\n                else cout<<\"YES\";\r\n        }\r\n}', 4, 5, 'Wrong Answer', '2026-06-25 07:51:20'),
(13, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    long long n;\r\n    cin>>n;\r\n    if (n<=1) cout<<\"NO\";\r\n    else if (n<=3) cout<<\"YES\";\r\n    else if (n%2==0 || n%3==0) cout<<\"NO\";\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    cout<<\"NO\";\r\n                }\r\n                else cout<<\"YES\";\r\n        }\r\n}', 4, 5, 'Wrong Answer', '2026-06-25 07:53:21'),
(14, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    long long n;\r\n    cin>>n;\r\n    bool kt=1;\r\n    if (n<=1) kt=0;\r\n    else if (n<=3) kt=1;\r\n    else if (n%2==0 || n%3==0) kt=0;\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    kt=0;\r\n                    break;\r\n                }\r\n        }\r\n    if (kt) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 5, 5, 'Accepted', '2026-06-25 07:54:17'),
(15, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n    if (n<=1) cout<<\"NO\";\r\n    else if (n<=3) cout<<\"YES\";\r\n    else if (n%2==0 || n%3==0) cout<<\"NO\";\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    cout<<\"NO\";\r\n                }\r\n                else cout<<\"YES\";\r\n        }\r\n}\r\n', 4, 5, 'Wrong Answer', '2026-06-25 08:04:38'),
(16, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    long long n;\r\n    cin>>n;\r\n    bool kt=1;\r\n    if (n<=1) kt=0;\r\n    else if (n<=3) kt=1;\r\n    else if (n%2==0 || n%3==0) kt=0;\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    kt=0;\r\n\r\n                }\r\n        }\r\n    if (kt) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 5, 5, 'Accepted', '2026-06-25 08:05:25'),
(17, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    long long n;\r\n    cin>>n;\r\n    bool kt=1;\r\n    if (n<=1) kt=0;\r\n    else if (n<=3) kt=1;\r\n    else if (n%2==0 || n%3==0) kt=0;\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    kt=0\r\n\r\n                }\r\n        }\r\n    if (kt) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 0, 5, 'Compile Error', '2026-06-25 08:05:43'),
(18, 1, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    long long n;\r\n    cin>>n;\r\n    bool kt=1;\r\n    if (n<=1) kt=0;\r\n    else if (n<=3) kt=1;\r\n    else if (n%2==0 || n%3==0) kt=0;\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    kt=0;\r\n\r\n                }\r\n        }\r\n    if (kt) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 5, 5, 'Accepted', '2026-06-25 08:06:05'),
(19, 3, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    long long n;\r\n    cin>>n;\r\n    bool kt=1;\r\n    if (n<=1) kt=0;\r\n    else if (n<=3) kt=1;\r\n    else if (n%2==0 || n%3==0) kt=0;\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    kt=0;\r\n\r\n                }\r\n        }\r\n    if (kt) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 5, 5, 'Accepted', '2026-06-25 08:14:37'),
(20, 2, 5, NULL, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    long long n;\r\n    cin>>n;\r\n    bool kt=1;\r\n    if (n<=1) kt=0;\r\n    else if (n<=3) kt=1;\r\n    else if (n%2==0 || n%3==0) kt=0;\r\n    else\r\n        {\r\n            for (int i=5;i*i<=n;i+=6)\r\n                if (n%i==0 || n%(i+2)==0) \r\n                {\r\n                    kt=0;\r\n\r\n                }\r\n        }\r\n    if (kt) cout<<\"YES\";\r\n    else cout<<\"NO\";\r\n}\r\n', 5, 5, 'Accepted', '2026-06-25 08:15:24'),
(21, 1, 1, 3, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,b;\r\n    cin>>a>>b;\r\n    cout<<a+b;\r\n}', 5, 5, 'Accepted', '2026-06-25 08:39:08'),
(22, 1, 1, 3, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,b;\r\n    cin>>a>>b;\r\n    cout<<a+b;\r\n}', 5, 5, 'Accepted', '2026-06-25 08:44:31'),
(23, 1, 1, 3, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,b;\r\n    cin>>a>>b;\r\n    cout<<a+b;\r\n', 0, 5, 'Compile Error', '2026-06-25 08:44:49'),
(24, 1, 2, 4, NULL, '#include<bits/sdtc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";', 0, 5, 'Compile Error', '2026-06-25 08:54:14'),
(25, 1, 2, 4, NULL, '#include<bits/sdtc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";\r\n}', 0, 5, 'Compile Error', '2026-06-25 08:54:19'),
(26, 1, 2, 4, NULL, '#include<bits/sdtc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";\r\n}', 0, 5, 'Compile Error', '2026-06-25 08:54:45'),
(27, 1, 2, 4, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";\r\n}', 5, 5, 'Accepted', '2026-06-25 08:55:10'),
(28, 1, 2, 4, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n	int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";\r\n}', 5, 5, 'Accepted', '2026-06-25 08:55:21'),
(29, 1, 2, 5, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";\r\n}', 5, 5, 'Accepted', '2026-06-25 08:58:12'),
(30, 1, 4, 5, NULL, '// Viết code của bạn tại đây...\r\n', 0, 5, 'Compile Error', '2026-06-25 08:58:38'),
(31, 1, 4, 5, NULL, '// Viết code của bạn tại đây...\r\nabc', 0, 5, 'Compile Error', '2026-06-25 08:58:51'),
(32, 1, 2, 6, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int n;\r\n    cin>>n;\r\n    if(n%2==0) cout<<\"Chan\";\r\n    else cout<<\"Le\";\r\n}', 5, 5, 'Accepted', '2026-06-25 10:11:44'),
(33, 2, 4, 7, NULL, '// Viết code của bạn tại đây...\r\n', 0, 5, 'Compile Error', '2026-06-25 12:14:09'),
(34, 1, 3, 9, NULL, '#include<bits/stdc++.h>\r\nusing namespace std;\r\nint main()\r\n{\r\n    int a,b,c;\r\n    cin>>a>>b>>c;\r\n    cout<<max(a,max(b,c));\r\n}', 5, 5, 'Accepted', '2026-06-25 13:35:28');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `submission_details`
--

CREATE TABLE `submission_details` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `testcase_id` int(11) NOT NULL,
  `status` enum('Success','Failed') NOT NULL,
  `time_used_ms` int(11) DEFAULT 0,
  `memory_used_kb` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `submission_details`
--

INSERT INTO `submission_details` (`id`, `submission_id`, `testcase_id`, `status`, `time_used_ms`, `memory_used_kb`) VALUES
(1, 1, 11, 'Failed', 176, 2048),
(2, 1, 12, 'Failed', 164, 3276),
(3, 1, 13, 'Failed', 207, 4300),
(4, 1, 14, 'Failed', 175, 2355),
(5, 1, 15, 'Failed', 165, 3379),
(6, 2, 11, 'Success', 151, 3174),
(7, 2, 12, 'Success', 88, 2560),
(8, 2, 13, 'Success', 233, 4300),
(9, 2, 14, 'Success', 141, 2252),
(10, 2, 15, 'Success', 114, 3072),
(11, 3, 1, 'Failed', 202, 3174),
(12, 3, 2, 'Failed', 82, 4608),
(13, 3, 3, 'Failed', 180, 2969),
(14, 3, 4, 'Failed', 148, 2867),
(15, 3, 5, 'Failed', 179, 4505),
(16, 4, 1, 'Success', 182, 2355),
(17, 4, 2, 'Success', 236, 2048),
(18, 4, 3, 'Success', 205, 2048),
(19, 4, 4, 'Success', 146, 2252),
(20, 4, 5, 'Success', 232, 2048),
(21, 5, 6, 'Success', 166, 4096),
(22, 5, 7, 'Success', 237, 3481),
(23, 5, 8, 'Success', 125, 2252),
(24, 5, 9, 'Success', 86, 3379),
(25, 5, 10, 'Success', 133, 3993),
(26, 6, 11, 'Success', 97, 3686),
(27, 6, 12, 'Success', 121, 2355),
(28, 6, 13, 'Success', 185, 3174),
(29, 6, 14, 'Success', 104, 3072),
(30, 6, 15, 'Success', 80, 4300),
(31, 7, 11, 'Success', 145, 2560),
(32, 7, 12, 'Success', 109, 3276),
(33, 7, 13, 'Success', 103, 3481),
(34, 7, 14, 'Success', 117, 3174),
(35, 7, 15, 'Success', 130, 2048),
(36, 8, 21, '', 0, 0),
(37, 9, 21, '', 0, 0),
(38, 10, 21, '', 0, 0),
(39, 11, 21, 'Success', 103, 3891),
(40, 11, 22, 'Success', 94, 3174),
(41, 11, 23, 'Success', 147, 2457),
(42, 11, 24, 'Failed', 86, 2764),
(43, 11, 25, 'Success', 148, 2150),
(44, 12, 21, 'Success', 166, 2867),
(45, 12, 22, 'Success', 229, 3686),
(46, 12, 23, 'Failed', 107, 3993),
(47, 12, 24, 'Success', 160, 3174),
(48, 12, 25, 'Success', 151, 2150),
(49, 13, 21, 'Success', 168, 3891),
(50, 13, 22, 'Success', 188, 3686),
(51, 13, 23, 'Failed', 167, 3276),
(52, 13, 24, 'Success', 240, 3276),
(53, 13, 25, 'Success', 196, 4608),
(54, 14, 21, 'Success', 100, 2355),
(55, 14, 22, 'Success', 96, 2662),
(56, 14, 23, 'Success', 147, 2048),
(57, 14, 24, 'Success', 207, 2560),
(58, 14, 25, 'Success', 145, 4198),
(59, 15, 21, 'Success', 125, 2969),
(60, 15, 22, 'Success', 137, 4096),
(61, 15, 23, 'Failed', 129, 4300),
(62, 15, 24, 'Success', 140, 4403),
(63, 15, 25, 'Success', 172, 2662),
(64, 16, 21, 'Success', 107, 3276),
(65, 16, 22, 'Success', 162, 2969),
(66, 16, 23, 'Success', 190, 3276),
(67, 16, 24, 'Success', 140, 4608),
(68, 16, 25, 'Success', 227, 3379),
(69, 17, 21, '', 0, 0),
(70, 18, 21, 'Success', 229, 4608),
(71, 18, 22, 'Success', 132, 2150),
(72, 18, 23, 'Success', 133, 3481),
(73, 18, 24, 'Success', 148, 2662),
(74, 18, 25, 'Success', 141, 3686),
(75, 19, 21, 'Success', 159, 2969),
(76, 19, 22, 'Success', 181, 4403),
(77, 19, 23, 'Success', 127, 2560),
(78, 19, 24, 'Success', 87, 3993),
(79, 19, 25, 'Success', 207, 2560),
(80, 20, 21, 'Success', 195, 3174),
(81, 20, 22, 'Success', 189, 3891),
(82, 20, 23, 'Success', 122, 3891),
(83, 20, 24, 'Success', 192, 2457),
(84, 20, 25, 'Success', 148, 2457),
(85, 21, 1, 'Success', 194, 2150),
(86, 21, 2, 'Success', 88, 2457),
(87, 21, 3, 'Success', 81, 3276),
(88, 21, 4, 'Success', 99, 3993),
(89, 21, 5, 'Success', 188, 3481),
(90, 22, 1, 'Success', 226, 3584),
(91, 22, 2, 'Success', 132, 3788),
(92, 22, 3, 'Success', 183, 4198),
(93, 22, 4, 'Success', 163, 2048),
(94, 22, 5, 'Success', 231, 2252),
(95, 23, 1, '', 0, 0),
(96, 24, 6, '', 0, 0),
(97, 25, 6, '', 0, 0),
(98, 26, 6, '', 0, 0),
(99, 27, 6, 'Success', 121, 3891),
(100, 27, 7, 'Success', 159, 4403),
(101, 27, 8, 'Success', 129, 4608),
(102, 27, 9, 'Success', 132, 2150),
(103, 27, 10, 'Success', 82, 3174),
(104, 28, 6, 'Success', 236, 3788),
(105, 28, 7, 'Success', 173, 3379),
(106, 28, 8, 'Success', 143, 4198),
(107, 28, 9, 'Success', 214, 3891),
(108, 28, 10, 'Success', 156, 2252),
(109, 29, 6, 'Success', 234, 3891),
(110, 29, 7, 'Success', 177, 3686),
(111, 29, 8, 'Success', 177, 2560),
(112, 29, 9, 'Success', 212, 3174),
(113, 29, 10, 'Success', 114, 4505),
(114, 30, 16, '', 0, 0),
(115, 31, 16, '', 0, 0),
(116, 32, 6, 'Success', 158, 2969),
(117, 32, 7, 'Success', 146, 2867),
(118, 32, 8, 'Success', 217, 3276),
(119, 32, 9, 'Success', 147, 4300),
(120, 32, 10, 'Success', 208, 3686),
(121, 33, 16, '', 0, 0),
(122, 34, 11, 'Success', 142, 4300),
(123, 34, 12, 'Success', 180, 3379),
(124, 34, 13, 'Success', 198, 2560),
(125, 34, 14, 'Success', 215, 3481),
(126, 34, 15, 'Success', 90, 4608);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `testcases`
--

CREATE TABLE `testcases` (
  `id` int(11) NOT NULL,
  `problem_id` int(11) NOT NULL,
  `input_data` text DEFAULT NULL,
  `expected_output` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `testcases`
--

INSERT INTO `testcases` (`id`, `problem_id`, `input_data`, `expected_output`) VALUES
(1, 1, '3 5', '8'),
(2, 1, '-2 7', '5'),
(3, 1, '0 0', '0'),
(4, 1, '100 -50', '50'),
(5, 1, '-10 -20', '-30'),
(6, 2, '4', 'Chan'),
(7, 2, '7', 'Le'),
(8, 2, '0', 'Chan'),
(9, 2, '-2', 'Chan'),
(10, 2, '-5', 'Le'),
(11, 3, '1 5 3', '5'),
(12, 3, '10 10 10', '10'),
(13, 3, '-5 -2 -9', '-2'),
(14, 3, '100 50 75', '100'),
(15, 3, '0 0 1', '1'),
(16, 4, '0', '1'),
(17, 4, '1', '1'),
(18, 4, '5', '120'),
(19, 4, '6', '720'),
(20, 4, '10', '3628800'),
(21, 5, '2', 'YES'),
(22, 5, '1', 'NO'),
(23, 5, '17', 'YES'),
(24, 5, '25', 'NO'),
(25, 5, '-5', 'NO');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','teacher','admin') DEFAULT 'student',
  `require_password_change` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `role`, `require_password_change`, `created_at`) VALUES
(1, 'phamdangtoan6112006@gmail.com', '$2y$10$Al6wyeqmOOPgD3EYlpgX7O9jX55fx55krrXFcViox3Z8pJhlW4mcm', 'admin', 0, '2026-06-23 10:32:37'),
(2, 'mitomsong1504@gmail.com', '$2y$10$Lsv9NjTm/VR5/mnHJyRJCuim5itiUPYiLJXkuI9X2Fz/JTsPKcAfm', 'student', 0, '2026-06-23 11:34:10'),
(3, 'toan.pd2415052@sis.hust.edu.vn', '$2y$10$3utzOltDnLKhCYVuh7VlIOLtwX3rGjZbn.LXDF9MhAXp3MyCcQpVi', 'teacher', 0, '2026-06-24 17:39:00'),
(4, 'Anh.DLH2417632@sis.hust.edu.vn', '$2y$10$URmnwgp6bk5vtndtOzX1R.mWbQT1i3Y5KXHsgtf/OKg0m9A5RVG5a', 'student', 1, '2026-06-24 17:48:50');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `attempt_answers`
--
ALTER TABLE `attempt_answers`
  ADD PRIMARY KEY (`attempt_id`,`question_id`,`option_id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `option_id` (`option_id`);

--
-- Chỉ mục cho bảng `contests`
--
ALTER TABLE `contests`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `contest_problems`
--
ALTER TABLE `contest_problems`
  ADD PRIMARY KEY (`contest_id`,`problem_id`),
  ADD KEY `problem_id` (`problem_id`);

--
-- Chỉ mục cho bảng `contest_status`
--
ALTER TABLE `contest_status`
  ADD PRIMARY KEY (`user_id`,`contest_id`),
  ADD KEY `contest_id` (`contest_id`);

--
-- Chỉ mục cho bảng `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Chỉ mục cho bảng `course_enrollments`
--
ALTER TABLE `course_enrollments`
  ADD PRIMARY KEY (`course_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Chỉ mục cho bảng `course_materials`
--
ALTER TABLE `course_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Chỉ mục cho bảng `course_problems`
--
ALTER TABLE `course_problems`
  ADD PRIMARY KEY (`course_id`,`problem_id`),
  ADD KEY `problem_id` (`problem_id`);

--
-- Chỉ mục cho bảng `course_quizzes`
--
ALTER TABLE `course_quizzes`
  ADD PRIMARY KEY (`course_id`,`quiz_id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Chỉ mục cho bảng `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Chỉ mục cho bảng `problems`
--
ALTER TABLE `problems`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Chỉ mục cho bảng `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Chỉ mục cho bảng `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `problem_id` (`problem_id`),
  ADD KEY `contest_id` (`contest_id`);

--
-- Chỉ mục cho bảng `submission_details`
--
ALTER TABLE `submission_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `submission_id` (`submission_id`),
  ADD KEY `testcase_id` (`testcase_id`);

--
-- Chỉ mục cho bảng `testcases`
--
ALTER TABLE `testcases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `problem_id` (`problem_id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `contests`
--
ALTER TABLE `contests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `course_materials`
--
ALTER TABLE `course_materials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT cho bảng `problems`
--
ALTER TABLE `problems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `submissions`
--
ALTER TABLE `submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT cho bảng `submission_details`
--
ALTER TABLE `submission_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT cho bảng `testcases`
--
ALTER TABLE `testcases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `attempt_answers`
--
ALTER TABLE `attempt_answers`
  ADD CONSTRAINT `attempt_answers_ibfk_1` FOREIGN KEY (`attempt_id`) REFERENCES `quiz_attempts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attempt_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attempt_answers_ibfk_3` FOREIGN KEY (`option_id`) REFERENCES `options` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `contest_problems`
--
ALTER TABLE `contest_problems`
  ADD CONSTRAINT `contest_problems_ibfk_1` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contest_problems_ibfk_2` FOREIGN KEY (`problem_id`) REFERENCES `problems` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `contest_status`
--
ALTER TABLE `contest_status`
  ADD CONSTRAINT `contest_status_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contest_status_ibfk_2` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `course_enrollments`
--
ALTER TABLE `course_enrollments`
  ADD CONSTRAINT `course_enrollments_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_enrollments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `course_materials`
--
ALTER TABLE `course_materials`
  ADD CONSTRAINT `course_materials_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `course_problems`
--
ALTER TABLE `course_problems`
  ADD CONSTRAINT `course_problems_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_problems_ibfk_2` FOREIGN KEY (`problem_id`) REFERENCES `problems` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `course_quizzes`
--
ALTER TABLE `course_quizzes`
  ADD CONSTRAINT `course_quizzes_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_quizzes_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  ADD CONSTRAINT `quiz_attempts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_attempts_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `submissions`
--
ALTER TABLE `submissions`
  ADD CONSTRAINT `submissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `submissions_ibfk_2` FOREIGN KEY (`problem_id`) REFERENCES `problems` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `submissions_ibfk_3` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `submission_details`
--
ALTER TABLE `submission_details`
  ADD CONSTRAINT `submission_details_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `submission_details_ibfk_2` FOREIGN KEY (`testcase_id`) REFERENCES `testcases` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `testcases`
--
ALTER TABLE `testcases`
  ADD CONSTRAINT `testcases_ibfk_1` FOREIGN KEY (`problem_id`) REFERENCES `problems` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
