<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$contest_id = $_GET['id'] ?? null;
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// [MỚI] Xử lý sự kiện "Hoàn thành bài thi"
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['finish_contest'])) {
    $stmt_finish = $pdo->prepare("INSERT IGNORE INTO contest_status (user_id, contest_id, is_finished) VALUES (?, ?, 1)");
    $stmt_finish->execute([$user_id, $contest_id]);
    header("Location: contest_view.php?id=$contest_id");
    exit;
}

// Lấy thông tin cuộc thi
$stmt = $pdo->prepare("SELECT * FROM contests WHERE id = ?");
$stmt->execute([$contest_id]);
$contest = $stmt->fetch();

$current_time = date('Y-m-d H:i:s');

if (!$contest || $current_time < $contest['start_time']) {
    echo "<div class='alert alert-danger bg-dark border-danger text-danger text-center mt-5'>Kỳ thi không tồn tại hoặc chưa đến giờ mở cửa.</div>";
    require_once 'includes/footer.php';
    exit;
}

$is_time_ended = ($current_time > $contest['end_time']);

// Kiểm tra xem User này đã bấm "Hoàn thành" chưa
$stmt_stat = $pdo->prepare("SELECT is_finished FROM contest_status WHERE user_id = ? AND contest_id = ?");
$stmt_stat->execute([$user_id, $contest_id]);
$has_finished = ($stmt_stat->fetchColumn() == 1);

// Kỳ thi kết thúc khi: Hết giờ HOẶC học sinh tự nộp bài
$is_ended = ($is_time_ended || $has_finished);

// Ẩn Navbar đối với Học sinh khi đang thi
if ($role == 'student' && !$is_ended) {
    echo "<style>.navbar { display: none !important; } body { padding-top: 30px; }</style>";
}

$has_seb = !empty($contest['seb_config_path']);
// Lấy danh tính của trình duyệt đang truy cập
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Nhận diện nếu trong danh tính có chứa chữ "SafeExamBrowser" HOẶC "SEB"
$is_using_seb = (strpos($user_agent, 'SafeExamBrowser') !== false || strpos($user_agent, 'SEB') !== false);
$seb_link = "seb://localhost/n12oj"; // Đường link kích hoạt SEB theo yêu cầu

$stmt_probs = $pdo->prepare("
    SELECT p.*,
           (SELECT MAX(CASE WHEN status = 'Accepted' THEN 2 ELSE 1 END) 
           FROM submissions s 
           WHERE s.problem_id = p.id AND s.user_id = ? AND s.contest_id = ?) as user_status
    FROM problems p
    JOIN contest_problems cp ON p.id = cp.problem_id
    WHERE cp.contest_id = ?
");
$stmt_probs->execute([$user_id, $contest_id, $contest_id]);
$problems = $stmt_probs->fetchAll();

$total_problems = count($problems);
$completed_problems = 0;
foreach ($problems as $p) {
    if ($p['user_status'] == 2) $completed_problems++;
}
?>

<div class="card p-4 mb-4" style="background-color: #16171e; border: 1px solid #232530;">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <?php if ($has_finished): ?>
                <span class="badge bg-success mb-2 text-uppercase letter-spacing-1">Đã nộp bài thi</span>
            <?php elseif ($is_time_ended): ?>
                <span class="badge bg-secondary mb-2 text-uppercase letter-spacing-1">Kỳ thi đã kết thúc</span>
            <?php elseif ($is_using_seb): ?>
                <span class="badge bg-danger mb-2 text-uppercase letter-spacing-1">🔒 MÔI TRƯỜNG SEB</span>
            <?php else: ?>
                <span class="badge bg-danger mb-2 text-uppercase letter-spacing-1">Đang trong chế độ thi</span>
            <?php endif; ?>
            
            <h2 class="fw-bold text-warning mb-0"><?= htmlspecialchars($contest['title']) ?></h2>
            <p class="text-white-50 mb-0 mt-1 small">Khóa đề lúc: <?= date('H:i d/m/Y', strtotime($contest['end_time'])) ?></p>
        </div>
        
        <div class="text-end">
            <div class="mb-3">
                <span class="text-white-50 small text-uppercase fw-bold me-2"><?= $has_finished ? 'Kết quả của bạn:' : 'Tiến độ của bạn:' ?></span>
                <span class="fs-3 fw-bold <?= ($completed_problems == $total_problems && $total_problems > 0) ? 'text-success' : 'text-warning' ?>" style="color: <?= ($completed_problems == $total_problems && $total_problems > 0) ? '#10b981' : '#f59e0b' ?> !important;">
                    <?= $completed_problems ?> / <?= $total_problems ?>
                </span>
            </div>
            
            <div class="d-flex justify-content-end gap-2 align-items-center">
                <?php if (!$is_ended): ?>
                    <?php if ($role == 'student' && (!$has_seb || $is_using_seb)): ?>
                        <form method="POST" class="m-0" onsubmit="return confirm('XÁC NHẬN NỘP BÀI THI?\n\nBạn sẽ không thể làm tiếp các bài tập sau khi bấm nút này!');">
                            <input type="hidden" name="finish_contest" value="1">
                            <button type="submit" class="btn btn-danger fw-bold px-4">Hoàn thành bài thi</button>
                        </form>
                    <?php endif; ?>
                    
                    <?php if ($role != 'student'): ?>
                        <a href="contests.php" class="btn btn-outline-danger fw-bold px-4">Tạm thoát (Chỉ GV)</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="contests.php" class="btn btn-outline-light fw-bold px-4">Quay về danh sách</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if ($role == 'student' && $has_seb && !$is_ended && !$is_using_seb): ?>
    <div id="seb-gateway" class="card p-5 text-center mb-4 border-danger" style="background-color: #16171e; box-shadow: 0 0 30px rgba(239, 68, 68, 0.2);">
        <div class="mb-4"><span style="font-size: 3rem;">🔒</span></div>
        <h3 class="fw-bold text-danger mb-3">YÊU CẦU BẢO MẬT KỲ THI</h3>
        <p class="text-white-50 mb-4 mx-auto" style="max-width: 600px;">Kỳ thi này yêu cầu sử dụng Safe Exam Browser. Nếu bạn truy cập bằng trình duyệt thông thường, trang web sẽ không hiển thị đề bài.</p>

        <div class="d-flex justify-content-center gap-3 mb-4">
            <a href="https://safeexambrowser.org/download_en.html" target="_blank" id="btn-seb-1" class="btn btn-outline-info fw-bold py-2 px-4" onclick="checkStep(1)">1. Tải ứng dụng SEB</a>
            <a href="<?= htmlspecialchars($contest['seb_config_path']) ?>" download id="btn-seb-2" class="btn btn-outline-warning fw-bold py-2 px-4" onclick="checkStep(2)">2. Tải File cấu hình</a>
            <a href="javascript:void(0)" id="btn-seb-3" class="btn btn-secondary fw-bold py-2 px-4 pointer-events-none" style="pointer-events: none;" onclick="triggerSEB()">3. Chạy cấu hình</a>
        </div>
        <p id="seb-status" class="small text-muted fw-bold">Vui lòng tải cài đặt App (1) và File cấu hình (2) trước khi chạy!</p>
    </div>
<?php else: ?>
    <h4 class="fw-bold text-white mb-3">📑 Danh sách các bài tập trong đề thi:</h4>
    <div class="row">
        <?php foreach($problems as $index => $p): 
            $status_text = 'Chưa làm'; $status_color = '#ef4444'; 
            if ($p['user_status'] == 2) { $status_text = 'Hoàn thành'; $status_color = '#10b981'; } 
            elseif ($p['user_status'] == 1) { $status_text = 'Đã làm (Chưa AC)'; $status_color = '#f59e0b'; }
        ?>
            <div class="col-md-12 mb-3">
                <div class="card p-3 shadow-sm d-flex flex-row justify-content-between align-items-center" style="background-color: #16171e; border: 1px solid #232530; border-left: 4px solid <?= $status_color ?> !important;">
                    <div>
                        <h5 class="mb-1 fw-bold text-white">Bài số <?= $index + 1 ?>: <?= htmlspecialchars($p['title']) ?></h5>
                        <div class="d-flex align-items-center mt-2 gap-3">
                            <small class="text-white-50">Ngôn ngữ: <span class="badge bg-dark border border-secondary text-warning text-uppercase"><?= $p['language'] ?></span></small>
                            <span class="text-white-50">|</span>
                            <small class="fw-bold" style="color: <?= $status_color ?>;">● Trạng thái: <?= $status_text ?></small>
                        </div>
                    </div>
                    <div>
                        <?php if (!$is_ended): ?>
                            <a href="solve.php?id=<?= $p['id'] ?>&contest_id=<?= $contest_id ?>" class="btn btn-warning fw-bold px-4 text-dark">Làm bài</a>
                        <?php else: ?>
                            <a href="solve.php?id=<?= $p['id'] ?>&contest_id=<?= $contest_id ?>" class="btn btn-outline-secondary fw-bold px-4">Xem lại đề & Code</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if ($role == 'student' && $has_seb && !$is_ended && !$is_using_seb): ?>
<script>
    const contestId = <?= $contest_id ?>;
    const storageKey = 'seb_unlocked_contest_' + contestId;
    let step1Done = false;
    let step2Done = false;

    // Load lại trang: Nếu đã chạy cấu hình trước đó thì nút 3 sáng ngay
    window.onload = function() {
        if(localStorage.getItem(storageKey) === 'true') {
            step1Done = true;
            step2Done = true;
            const btn3 = document.getElementById('btn-seb-3');
            if(btn3) {
                btn3.classList.replace('btn-secondary', 'btn-danger');
                btn3.style.pointerEvents = 'auto';
                document.getElementById('seb-status').innerText = "✅ Hệ thống ghi nhận bạn đã tải file. Bấm Nút 3 để gọi phần mềm SEB!";
                document.getElementById('seb-status').classList.replace('text-muted', 'text-success');
            }
        }
    };

    function checkStep(step) {
        if (step === 1) {
            // Bấm lại nút 1 -> Phải làm lại từ đầu
            localStorage.removeItem(storageKey);
            step1Done = true;
            step2Done = false;
            
            document.getElementById('btn-seb-1').classList.replace('btn-outline-info', 'btn-info');
            document.getElementById('btn-seb-1').classList.add('text-dark');
            
            // Khóa lại nút 3
            const btn3 = document.getElementById('btn-seb-3');
            btn3.classList.replace('btn-danger', 'btn-secondary');
            btn3.style.pointerEvents = 'none';
            
            document.getElementById('seb-status').innerText = "🔄 Đã reset tiến trình. Vui lòng bấm Nút 2 để tiếp tục.";
            document.getElementById('seb-status').classList.replace('text-success', 'text-warning');
        }
        if (step === 2) {
            step2Done = true;
            document.getElementById('btn-seb-2').classList.replace('btn-outline-warning', 'btn-warning');
            document.getElementById('btn-seb-2').classList.add('text-dark');
        }

        // Mở khóa Nút 3 khi đủ bước
        if (step1Done && step2Done) {
            const btn3 = document.getElementById('btn-seb-3');
            btn3.classList.replace('btn-secondary', 'btn-danger');
            btn3.style.pointerEvents = 'auto'; 
            document.getElementById('seb-status').innerText = "✅ Hãy bấm [Nút 3] để chạy cấu hình!";
            document.getElementById('seb-status').classList.replace('text-muted', 'text-success');
            document.getElementById('seb-status').classList.replace('text-warning', 'text-success');
        }
    }

    function triggerSEB() {
        // Lưu lại bộ nhớ
        localStorage.setItem(storageKey, 'true');
        
        // Gọi thẳng vào app SEB (Trình duyệt thường sẽ hiện thông báo Mở Ứng Dụng)
        window.location.href = '<?= $seb_link ?>'; 
        
        document.getElementById('seb-status').innerText = "⏳ Đang gọi phần mềm SEB... (Hãy bấm Cho phép ở thông báo của trình duyệt nhé!)";
        document.getElementById('seb-status').classList.replace('text-success', 'text-warning');
    }
</script>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>