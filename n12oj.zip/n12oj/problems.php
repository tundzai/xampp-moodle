<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$role = $_SESSION['role'];

// Xử lý Xóa Bài Tập (Giáo viên và Admin đều có quyền)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_problem_id'])) {
    if (in_array($role, ['teacher', 'admin'])) {
        $del_id = $_POST['delete_problem_id'];
        // Xóa bài tập (ON DELETE CASCADE trong SQL sẽ tự xóa testcase và submissions liên quan)
        $pdo->prepare("DELETE FROM problems WHERE id = ?")->execute([$del_id]);
        echo "<script>alert('Đã xóa bài tập thành công!'); window.location='problems.php';</script>";
        exit;
    }
}

$stmt = $pdo->query("SELECT * FROM problems ORDER BY id DESC");
$problems = $stmt->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-white">💻 Danh sách Bài tập Thực hành</h2>
    <?php if (in_array($role, ['teacher', 'admin'])): ?>
        <a href="create_problem.php" class="btn btn-primary fw-bold text-white">+ Tạo bài tập mới</a>
    <?php endif; ?>
</div>

<div class="card p-3 border-0 shadow-lg">
    <div class="table-responsive">
        <table class="table table-dark table-hover align-middle mb-0" style="border-color: #232530;">
            <thead style="background-color: #0d0e12;">
                <tr>
                    <th class="py-3 px-4">ID</th>
                    <th class="py-3">Tên bài tập</th>
                    <th class="py-3 text-center">Ngôn ngữ</th>
                    <th class="py-3 text-center">Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($problems) == 0): ?>
                    <tr><td colspan="4" class="text-center text-white-50 py-5">Chưa có bài tập nào.</td></tr>
                <?php else: ?>
                    <?php foreach ($problems as $p): ?>
                        <tr style="border-bottom: 1px solid #232530;">
                            <td class="px-4 text-white-50">#<?= $p['id'] ?></td>
                            <td class="fw-bold text-white"><?= htmlspecialchars($p['title']) ?></td>
                            <td class="text-center"><span class="badge bg-warning text-dark text-uppercase"><?= htmlspecialchars($p['language']) ?></span></td>
                            <td class="text-center">
                                <a href="solve.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-success fw-bold px-3">Làm bài</a>
                                
                                <?php if (in_array($role, ['teacher', 'admin'])): ?>
                                    <a href="edit_problem.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-info fw-bold ms-1 text-dark">Sửa</a>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('⚠️ Chắc chắn xóa bài tập này? (Sẽ xóa toàn bộ bài nộp và testcase liên quan)');">
                                        <input type="hidden" name="delete_problem_id" value="<?= $p['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger fw-bold ms-1">Xóa</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>