<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_course_id'])) {
    $del_id = $_POST['delete_course_id'];
    $can_delete = false;
    if ($role == 'admin') {
        $can_delete = true;
    } elseif ($role == 'teacher') {
        $stmt_check = $pdo->prepare("SELECT 1 FROM courses WHERE id = ? AND teacher_id = ?");
        $stmt_check->execute([$del_id, $user_id]);
        if ($stmt_check->fetch()) $can_delete = true;
    }
    if ($can_delete) {
        $pdo->prepare("DELETE FROM courses WHERE id = ?")->execute([$del_id]);
        echo "<script>alert('Đã xóa khóa học thành công!'); window.location='courses.php';</script>";
        exit;
    }
}

if ($role == 'admin') {
    $stmt = $pdo->query("SELECT c.*, u.email as teacher_name FROM courses c JOIN users u ON c.teacher_id = u.id ORDER BY c.id DESC");
    $courses = $stmt->fetchAll();
} elseif ($role == 'teacher') {
    $stmt = $pdo->prepare("SELECT c.*, u.email as teacher_name FROM courses c JOIN users u ON c.teacher_id = u.id WHERE c.teacher_id = ? ORDER BY c.id DESC");
    $stmt->execute([$user_id]);
    $courses = $stmt->fetchAll();
} else {
    $stmt = $pdo->prepare("SELECT c.*, u.email as teacher_name FROM courses c JOIN users u ON c.teacher_id = u.id JOIN course_enrollments ce ON c.id = ce.course_id WHERE ce.user_id = ? ORDER BY c.id DESC");
    $stmt->execute([$user_id]);
    $courses = $stmt->fetchAll();
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold mb-1" style="color: var(--accent-purple);">🎓Khóa Học</h2>
        <p class="text-muted mb-0 small">Nơi cung cấp bài giảng, tài liệu và thực hành tổng hợp</p>
    </div>
    <?php if (in_array($role, ['teacher', 'admin'])): ?>
        <a href="create_course.php" class="btn btn-primary shadow-sm">+ Tạo Khóa Học Mới</a>
    <?php endif; ?>
</div>

<div class="row">
    <?php if (count($courses) == 0): ?>
        <?php if ($role == 'student'): ?>
            <div class="col-12">
                <div class="alert alert-danger bg-dark text-danger text-center p-5 shadow-lg border-0 rounded-4">
                    <h4 class="fw-bold mb-3">Bạn chưa được thêm vào khóa học nào!</h4>
                    <p class="mb-0 text-muted">Vui lòng liên hệ với Giáo viên bộ môn để được cấp quyền truy cập vào lớp học.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="col-12 text-center py-5 card border-0 border-top border-3 border-secondary">
                <p class="text-muted mb-0 fs-5">Chưa có khóa học nào được tạo trên hệ thống.</p>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <?php foreach ($courses as $c): ?>
            <div class="col-md-4 mb-4">
                <div class="card p-4 h-100 border-0" style="border-top: 4px solid var(--accent-purple) !important;">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge bg-secondary mb-2">Lớp học trực tuyến</span>
                    </div>
                    <h4 class="fw-bold text-white text-truncate mb-3" title="<?= htmlspecialchars($c['title']) ?>"><?= htmlspecialchars($c['title']) ?></h4>
                    
                    <div class="d-flex align-items-center mb-3">
                        <div class="rounded-circle d-flex justify-content-center align-items-center" style="width: 32px; height: 32px; background-color: rgba(139, 92, 246, 0.2); color: var(--accent-purple);">
                            👨‍🏫
                        </div>
                        <div class="ms-2">
                            <p class="text-white-50 small mb-0 lh-1">Giảng viên phụ trách</p>
                            <span class="text-white fw-semibold small"><?= htmlspecialchars($c['teacher_name']) ?></span>
                        </div>
                    </div>

                    <p class="text-muted small" style="display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">
                        <?= htmlspecialchars($c['description'] ?: 'Khóa học này chưa có lời mô tả chi tiết từ giảng viên.') ?>
                    </p>
                    
                    <div class="mt-auto d-flex gap-2 pt-3 border-top border-secondary" style="border-color: rgba(255,255,255,0.05) !important;">
                        <a href="course_view.php?id=<?= $c['id'] ?>" class="btn btn-primary flex-grow-1">Vào Lớp Học ➜</a>
                        
                        <?php if ($role == 'admin' || ($role == 'teacher' && $c['teacher_id'] == $user_id)): ?>
                            <form method="POST" class="m-0" onsubmit="return confirm('⚠️ Xóa toàn bộ khóa học, tài liệu và thành viên trong khóa này?');">
                                <input type="hidden" name="delete_course_id" value="<?= $c['id'] ?>">
                                <button type="submit" class="btn btn-outline-secondary" title="Xóa khóa học">🗑️</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>