<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($new_password) || empty($confirm_password)) {
        $error = "Vui lòng nhập đầy đủ mật khẩu.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Mật khẩu xác nhận không trùng khớp.";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        
        $stmt = $pdo->prepare("UPDATE users SET password = ?, require_password_change = 0 WHERE id = ?");
        if ($stmt->execute([$hashed_password, $_SESSION['user_id']])) {
            $_SESSION['require_change'] = 0;
            $success = "Đổi mật khẩu mới thành công! Đang chuyển hướng về trang chủ...";
            echo "<script>setTimeout(function(){ window.location.href = 'problems.php'; }, 2000);</script>";
        } else {
            $error = "Đã xảy ra lỗi khi cập nhật mật khẩu mới.";
        }
    }
}
?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card p-4 border border-warning">
            <h3 class="text-center mb-4 fw-bold text-warning">YÊU CẦU ĐỔI MẬT KHẨU</h3>
            <p class="text-muted text-center small">Tài khoản này đang sử dụng mật khẩu khôi phục tạm thời từ hệ thống, bạn cần thiết lập mật khẩu cá nhân mới để tiếp tục.</p>
            <?php if($error): ?> <div class="alert alert-danger"><?= $error ?></div> <?php endif; ?>
            <?php if($success): ?> <div class="alert alert-success"><?= $success ?></div> <?php endif; ?>
            <form action="change_password.php" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Mật khẩu mới của bạn</label>
                    <input type="password" name="new_password" class="form-control" required placeholder="Nhập mật khẩu mới">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Xác nhận mật khẩu mới</label>
                    <input type="password" name="confirm_password" class="form-control" required placeholder="Nhập lại mật khẩu mới">
                </div>
                <button type="submit" class="btn btn-warning w-100 py-2 fw-bold text-dark">Lưu Mật Khẩu & Đăng Nhập</button>
            </form>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>