<?php
// Tích hợp sẵn Header đã có chứa CSS nền đen hiện đại
require_once 'includes/header.php';
?>

<style>
    /* Tuỳ chỉnh phong cách riêng cho trang chủ */
    .hero-section {
        padding: 80px 0 60px;
        text-align: center;
        animation: fadeIn 1s ease-in-out;
    }
    .hero-logo {
        height: 120px;
        max-width: 280px;
        width: auto;
        display: block;
        margin: 0 auto 18px;
    }
    
    .hero-title {
        font-size: 3.5rem;
        font-weight: 900;
        /* Hiệu ứng chữ chuyển màu */
        background: linear-gradient(90deg, #10b981, #3b82f6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 20px;
        letter-spacing: 2px;
    }
    
    .hero-subtitle {
        font-size: 1.2rem;
        color: #8a8fab;
        margin-bottom: 40px;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
        line-height: 1.6;
    }
    
    .feature-card {
        background-color: #16171e;
        border: 1px solid #232530;
        border-radius: 12px;
        padding: 40px 30px;
        transition: transform 0.3s ease, box-shadow 0.3s ease, border-color 0.3s;
        height: 100%;
    }
    
    .feature-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.8);
        border-color: #3b82f6;
    }
    
    .feature-icon {
        font-size: 3.5rem;
        margin-bottom: 20px;
        display: inline-block;
    }
    
    .cta-btn {
        padding: 14px 40px;
        font-size: 1.1rem;
        border-radius: 50px;
        text-transform: uppercase;
        letter-spacing: 1px;
        transition: transform 0.2s;
    }
    
    .cta-btn:hover {
        transform: scale(1.05);
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="hero-section">
    <img src="imgs/logo.png" alt="N12OJ" class="hero-logo">
    <h1 class="hero-title">N12OJ</h1>
    <p class="hero-subtitle">Nền tảng rèn luyện kỹ năng lập trình, tổ chức thi trắc nghiệm và đánh giá tự động chuyên nghiệp hàng đầu.</p>
    
    <div class="mt-4">
        <?php if (!isset($_SESSION['user_id'])): ?>
            <a href="login.php" class="btn btn-success cta-btn fw-bold me-3 shadow-lg">Bắt Đầu Đăng Nhập</a>
            <a href="register.php" class="btn btn-outline-light cta-btn fw-bold">Tạo Tài Khoản</a>
        <?php else: ?>
            <a href="problems.php" class="btn btn-success cta-btn fw-bold me-3 shadow-lg">Luyện Tập Code Ngay</a>
            <a href="quizzes.php" class="btn btn-warning text-dark cta-btn fw-bold">Làm Trắc Nghiệm</a>
        <?php endif; ?>
    </div>
</div>

<div class="row mt-5 mb-5 px-3">
    <div class="col-md-4 mb-4">
        <div class="feature-card text-center">
            <div class="feature-icon">💻</div>
            <h4 class="fw-bold text-white mb-3">Chấm Code Tự Động</h4>
            <p class="text-muted">Hỗ trợ đa dạng ngôn ngữ như C, C++, Python, Java. Trình biên dịch mạnh mẽ đánh giá thời gian thực qua Jobe Server.</p>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="feature-card text-center" style="border-top: 3px solid #f59e0b;">
            <div class="feature-icon">📝</div>
            <h4 class="fw-bold text-white mb-3">Trắc Nghiệm Đa Dạng</h4>
            <p class="text-muted">Hệ thống câu hỏi trắc nghiệm thông minh, tự động lưu nháp realtime, trả kết quả tức thì với độ phân giải lỗi chi tiết.</p>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="feature-card text-center">
            <div class="feature-icon">🏆</div>
            <h4 class="fw-bold text-white mb-3">Kỳ Thi Cạnh Tranh</h4>
            <p class="text-muted">Tham gia các kỳ thi lập trình căng thẳng, hệ thống tính giờ chính xác bằng server đảm bảo công bằng tuyệt đối.</p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>