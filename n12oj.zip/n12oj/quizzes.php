<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$role = $_SESSION['role'];

// Xử lý Xóa Quiz (GV/Admin)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_quiz_id'])) {
    if (in_array($role, ['teacher', 'admin'])) {
        $del_id = $_POST['delete_quiz_id'];
        $pdo->prepare("DELETE FROM quizzes WHERE id = ?")->execute([$del_id]);
        echo "<script>alert('Đã xóa bài trắc nghiệm thành công!'); window.location='quizzes.php';</script>";
        exit;
    }
}

$stmt = $pdo->query("SELECT * FROM quizzes ORDER BY id DESC");
$quizzes = $stmt->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-warning">📝 Danh sách Bài Trắc Nghiệm</h2>
    <?php if (in_array($role, ['teacher', 'admin'])): ?>
        <a href="create_quiz.php" class="btn btn-warning fw-bold text-dark">+ Tạo Quiz Mới</a>
    <?php endif; ?>
</div>

<div class="row">
    <?php if(count($quizzes) == 0): ?>
        <div class="col-12 text-center text-white-50 py-5 card">Chưa có bài trắc nghiệm nào.</div>
    <?php else: ?>
        <?php foreach($quizzes as $q): ?>
            <div class="col-md-4 mb-4">
                <div class="card p-4 h-100 border-warning border-opacity-50">
                    <h5 class="fw-bold text-white mb-2"><?= htmlspecialchars($q['title']) ?></h5>
                    <p class="text-white-50 small mb-3">Tạo lúc: <?= date('d/m/Y', strtotime($q['created_at'])) ?></p>
                    <div class="mt-auto d-flex gap-2">
                        <a href="take_quiz.php?id=<?= $q['id'] ?>" class="btn btn-warning fw-bold text-dark flex-grow-1">Làm bài</a>
                        
                        <?php if (in_array($role, ['teacher', 'admin'])): ?>
                            <form method="POST" class="m-0" onsubmit="return confirm('⚠️ Xóa Quiz này sẽ xóa toàn bộ câu hỏi và điểm số của học sinh liên quan. Tiếp tục?');">
                                <input type="hidden" name="delete_quiz_id" value="<?= $q['id'] ?>">
                                <button type="submit" class="btn btn-outline-danger fw-bold">🗑️</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>