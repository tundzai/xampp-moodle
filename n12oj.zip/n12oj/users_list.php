<?php
require_once 'includes/header.php';

// Bảo mật cấp cao: Kẻ lạ truy cập sẽ bị đá văng
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo "<div class='alert alert-danger text-center'><h3>⛔ KHO TÀI LIỆU MẬT</h3><p>Bạn không có quyền truy cập trang này!</p></div>";
    require_once 'includes/footer.php';
    exit;
}

$message = '';

// Xử lý các thao tác của Admin
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $target_uid = (int)$_POST['target_uid'];
    $target_email = $_POST['target_email'];

    if ($target_uid === $_SESSION['user_id']) {
        $message = "<div class='alert alert-warning'>Không thể tự thay đổi quyền của chính mình!</div>";
    } else {
        try {
            if ($action == 'make_teacher') {
                $pdo->prepare("UPDATE users SET role = 'teacher' WHERE id = ?")->execute([$target_uid]);
                $message = "<div class='alert alert-success'>✅ Đã nâng cấp <b>$target_email</b> lên Giáo viên.</div>";
            } elseif ($action == 'make_student') {
                $pdo->prepare("UPDATE users SET role = 'student' WHERE id = ?")->execute([$target_uid]);
                $message = "<div class='alert alert-success'>⬇️ Đã hạ quyền <b>$target_email</b> xuống Học sinh.</div>";
            } elseif ($action == 'reset_pass') {
                $default_pass = '123456';
                $hash = password_hash($default_pass, PASSWORD_BCRYPT);
                // Đổi pass và bật cờ ép buộc họ phải đổi mật khẩu ngay lần tới đăng nhập
                $pdo->prepare("UPDATE users SET password = ?, require_password_change = 1 WHERE id = ?")->execute([$hash, $target_uid]);
                $message = "<div class='alert alert-info'>🔑 Đã reset mật khẩu của <b>$target_email</b> về: <b>$default_pass</b></div>";
            }
        } catch (Exception $e) {
            $message = "<div class='alert alert-danger'>Lỗi DB: " . $e->getMessage() . "</div>";
        }
    }
}

// Lấy danh sách toàn bộ Users
$stmt = $pdo->query("SELECT id, email, role, created_at FROM users ORDER BY role ASC, id DESC");
$users = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-white"><span class="text-danger">🛡️ Admin</span> - Quản Lý Hệ Thống Users</h2>
</div>

<?= $message ?>

<div class="card overflow-hidden">
    <div class="table-responsive">
        <table class="table table-dark table-hover mb-0 align-middle">
            <thead style="background-color: #0d0e12;">
                <tr>
                    <th class="py-3 px-4">ID</th>
                    <th class="py-3">Tài khoản (Email)</th>
                    <th class="py-3 text-center">Vai trò hiện tại</th>
                    <th class="py-3">Ngày tham gia</th>
                    <th class="py-3 text-end px-4">Hành động (Phân quyền & Reset)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td class="px-4 text-white-50">#<?= $u['id'] ?></td>
                        <td class="fw-bold <?= $u['role'] == 'admin' ? 'text-danger' : 'text-white' ?>">
                            <?= htmlspecialchars($u['email']) ?>
                            <?php if($u['id'] == $_SESSION['user_id']): ?> <span class="badge bg-secondary ms-1 small">Bạn</span> <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if ($u['role'] == 'admin'): ?>
                                <span class="badge bg-danger">Quản Trị Viên (Admin)</span>
                            <?php elseif ($u['role'] == 'teacher'): ?>
                                <span class="badge bg-warning text-dark">Giáo Viên (Teacher)</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Học Sinh (Student)</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-white-50 small"><?= date('d/m/Y H:i', strtotime($u['created_at'])) ?></td>
                        <td class="text-end px-4">
                            <?php if ($u['role'] != 'admin'): ?>
                                <div class="d-flex justify-content-end gap-2">
                                    <!-- Nút Reset Mật Khẩu -->
                                    <form method="POST" action="users_list.php" onsubmit="return confirm('Mật khẩu sẽ bị đổi thành 123456. Xác nhận?');">
                                        <input type="hidden" name="action" value="reset_pass">
                                        <input type="hidden" name="target_uid" value="<?= $u['id'] ?>">
                                        <input type="hidden" name="target_email" value="<?= htmlspecialchars($u['email']) ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-info">🔑 Reset Pass</button>
                                    </form>

                                    <!-- Nút Lên/Xuống Quyền -->
                                    <?php if ($u['role'] == 'student'): ?>
                                        <form method="POST" action="users_list.php">
                                            <input type="hidden" name="action" value="make_teacher">
                                            <input type="hidden" name="target_uid" value="<?= $u['id'] ?>">
                                            <input type="hidden" name="target_email" value="<?= htmlspecialchars($u['email']) ?>">
                                            <button type="submit" class="btn btn-sm btn-success">⬆️ Lên Giáo Viên</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="POST" action="users_list.php" onsubmit="return confirm('Thu hồi quyền giáo viên của tài khoản này?');">
                                            <input type="hidden" name="action" value="make_student">
                                            <input type="hidden" name="target_uid" value="<?= $u['id'] ?>">
                                            <input type="hidden" name="target_email" value="<?= htmlspecialchars($u['email']) ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-warning">⬇️ Hạ quyền</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="text-muted small italic">Không thể thao tác Admin</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="text-center mt-3 text-white-50 small">
    <p>💡 <b>Ghi chú:</b> Mật khẩu người dùng được mã hóa một chiều Bcrypt theo tiêu chuẩn quốc tế nên không thể xem được. Để cấp lại mật khẩu cho người dùng quên, hãy dùng nút <b>Reset Pass</b>.</p>
</div>

<?php require_once 'includes/footer.php'; ?>