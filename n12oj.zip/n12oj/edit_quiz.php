<?php
require_once 'includes/header.php';
// Fix: Cho phép cả teacher và admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'admin'])) { header("Location: quizzes.php"); exit; }

$quiz_id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM quizzes WHERE id = ?"); $stmt->execute([$quiz_id]);
$quiz = $stmt->fetch();
if (!$quiz) die("Không tìm thấy Quiz!");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['title'])) {
    $title = trim($_POST['title']); $duration = (int)$_POST['duration'];
    $questions = $_POST['questions'] ?? [];

    try {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE quizzes SET title=?, duration_minutes=? WHERE id=?")->execute([$title, $duration, $quiz_id]);
        
        $pdo->prepare("DELETE FROM questions WHERE quiz_id=?")->execute([$quiz_id]);
        
        foreach ($questions as $q) {
            $q_text = trim($q['text']); if (empty($q_text)) continue;
            $stmt_q = $pdo->prepare("INSERT INTO questions (quiz_id, question_text) VALUES (?, ?)");
            $stmt_q->execute([$quiz_id, $q_text]); $question_id = $pdo->lastInsertId();

            if (isset($q['options'])) {
                foreach ($q['options'] as $opt_index => $opt_text) {
                    $o_text = trim($opt_text); if (empty($o_text)) continue;
                    $is_correct = isset($q['correct']) && in_array($opt_index, $q['correct']) ? 1 : 0;
                    $pdo->prepare("INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)")->execute([$question_id, $o_text, $is_correct]);
                }
            }
        }
        $pdo->commit();
        echo "<script>alert('Sửa Quiz Thành Công!'); window.location='quizzes.php';</script>"; exit;
    } catch (Exception $e) { $pdo->rollBack(); $error = $e->getMessage(); }
}

$stmt_q = $pdo->prepare("SELECT * FROM questions WHERE quiz_id = ?"); $stmt_q->execute([$quiz_id]);
$old_questions = $stmt_q->fetchAll();
foreach ($old_questions as &$oq) {
    $stmt_o = $pdo->prepare("SELECT * FROM options WHERE question_id = ?"); $stmt_o->execute([$oq['id']]);
    $oq['options'] = $stmt_o->fetchAll();
}
$json_data = json_encode($old_questions);
?>
<style>
.create-check { appearance: none; width: 24px; height: 24px; border: 2px solid #fff; border-radius: 4px; background-color: transparent; cursor: pointer; position: relative; margin-left: 15px; }
.create-check:checked::after { content: 'x'; position: absolute; color: #fff; font-size: 18px; font-weight: bold; top: 50%; left: 50%; transform: translate(-50%, -60%); }
</style>

<h2 class="fw-bold text-warning mb-4">✏️ Chỉnh sửa Quiz</h2>
<form action="edit_quiz.php?id=<?= $quiz_id ?>" method="POST" id="quizForm">
    <div class="card p-4">
        <div class="row">
            <div class="col-md-8">
                <label class="fw-bold">Tiêu đề Quiz</label>
                <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($quiz['title']) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="fw-bold">Thời gian làm bài (Phút)</label>
                <input type="number" name="duration" class="form-control" value="<?= $quiz['duration_minutes'] ?>" required min="1">
            </div>
        </div>
    </div>
    <div id="questions-container"></div>
    <button type="button" class="btn btn-outline-info w-100 mb-4 py-2" onclick="addBlankQuestion()">+ Thêm Câu Hỏi Mới</button>
    <div class="text-end">
        <a href="quizzes.php" class="btn btn-outline-secondary px-4 me-2">Hủy bỏ</a>
        <button type="submit" class="btn btn-primary px-5 py-2 fw-bold text-dark fs-5">Thành Công (Cập nhật)</button>
    </div>
</form>

<script>
let qIndex = 0;
const oldData = <?= $json_data ?>;

function renderQuestion(qData) {
    const container = document.getElementById('questions-container');
    const html = `
    <div class="card p-4 border-warning mb-4 question-block">
        <div class="d-flex justify-content-between mb-2">
            <h5 class="fw-bold text-info">Câu hỏi</h5>
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.question-block').remove()">Xóa</button>
        </div>
        <textarea name="questions[${qIndex}][text]" class="form-control mb-3" required rows="2">${qData ? qData.question_text : ''}</textarea>
        <div id="opts_${qIndex}"></div>
        <button type="button" class="btn btn-sm btn-outline-light mt-3" onclick="addBlankOption(${qIndex})">+ Thêm đáp án</button>
    </div>`;
    container.insertAdjacentHTML('beforeend', html);
    
    if (qData && qData.options) {
        qData.options.forEach((opt, idx) => {
            const isChecked = opt.is_correct == 1 ? 'checked' : '';
            addOptionHTML(qIndex, idx, opt.option_text, isChecked);
        });
    } else {
        addBlankOption(qIndex); addBlankOption(qIndex);
    }
    qIndex++;
}

function addBlankQuestion() { renderQuestion(null); }
function addBlankOption(qId) {
    const oIndex = document.getElementById(`opts_${qId}`).children.length;
    addOptionHTML(qId, oIndex, '', '');
}
function addOptionHTML(qId, oIndex, text, checkedStr) {
    const html = `
    <div class="d-flex align-items-center mb-2">
        <input type="text" name="questions[${qId}][options][${oIndex}]" class="form-control" value="${text.replace(/"/g, '&quot;')}" required>
        <input type="checkbox" name="questions[${qId}][correct][]" value="${oIndex}" class="create-check" ${checkedStr}>
    </div>`;
    document.getElementById(`opts_${qId}`).insertAdjacentHTML('beforeend', html);
}

if(oldData.length > 0) { oldData.forEach(q => renderQuestion(q)); } else { addBlankQuestion(); }
</script>
<?php require_once 'includes/footer.php'; ?>