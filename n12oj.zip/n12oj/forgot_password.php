<?php
// Tải thủ công PHPMailer từ thư mục vendor hoặc src nếu có
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'includes/header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);

    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        $error = "Không tìm thấy tài khoản nào ứng với email này.";
    } else {
        // Tạo mật khẩu ngẫu nhiên mới
        $new_raw_pass = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 8);
        $hashed_password = password_hash($new_raw_pass, PASSWORD_BCRYPT);

        // Cập nhật cơ sở dữ liệu và đặt cờ require_password_change = 1
        $stmt = $pdo->prepare("UPDATE users SET password = ?, require_password_change = 1 WHERE email = ?");
        $stmt->execute([$hashed_password, $email]);

        // Cấu hình gửi mail bằng PHPMailer thực tế (Yêu cầu điền chính xác tài khoản Gmail của bạn)
        // Nếu chưa cấu hình kịp file PHPMailer bên ngoài, dòng code này giả định file nằm trong mục phpmailer/
        $mail_path_exception = __DIR__ . '/phpmailer/Exception.php';
        $mail_path_phpmailer = __DIR__ . '/phpmailer/PHPMailer.php';
        $mail_path_smtp = __DIR__ . '/phpmailer/SMTP.php';

        if (file_exists($mail_path_exception) && file_exists($mail_path_phpmailer) && file_exists($mail_path_smtp)) {
            require_once $mail_path_exception;
            require_once $mail_path_phpmailer;
            require_once $mail_path_smtp;

            $mail = new PHPMailer(true);
            try {
                // Cấu hình máy chủ SMTP Gmail
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'tongcamvu111@gmail.com'; // ĐIỀN EMAIL CỦA BẠN VÀO ĐÂY
                $mail->Password   = 'lnlb bgva gvwt mnjl';    // ĐIỀN MẬT KHẨU ỨNG DỤNG VÀO ĐÂY
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;
                $mail->CharSet    = 'UTF-8';

                // Người nhận
                $mail->setFrom('YOUR_GMAIL_HERE@gmail.com', 'N12OJ Xin Chao');
                $mail->addAddress($email);

                // Nội dung Email
                $mail->isHTML(true);
                $mail->Subject = 'Khôi phục mật khẩu - N12OJ';
                $mail->Body    = "Chào bạn, <br><br>Hệ thống đã cập nhật lại mật khẩu mới cho tài khoản của bạn.<br>" .
                                 "Mật khẩu đăng nhập mới là: <strong>$new_raw_pass</strong><br><br>" .
                                 "Sau khi đăng nhập lại, hệ thống sẽ tự động yêu cầu bạn đổi mật khẩu của mình ngay lập tức.";

                $mail->send();
                $success = "Hệ thống đã tạo mật khẩu mới và gửi thành công tới hòm thư của bạn!";
            } catch (Exception $e) {
                $error = "Mail không thể gửi đi. Lỗi chi tiết: {$mail->ErrorInfo}. <br>[LƯU Ý]: Mật khẩu mới cập nhật trong DB là: <strong>$new_raw_pass</strong> (bạn có thể lấy để test tạm thời).";
            }
        } else {
            $success = "Đã cập nhật DB thành công! [THÔNG BÁO]: Do bạn chưa tải thư mục PHPMailer đặt vào thư mục 'phpmailer/', hệ thống in trực tiếp mật khẩu mới để bạn test nhanh: Mật khẩu mới của bạn là: <strong>$new_raw_pass</strong>";
        }
    }
}
?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card p-4">
            <h3 class="text-center mb-4 fw-bold text-danger">QUÊN MẬT KHẨU</h3>
            <?php if($error): ?> <div class="alert alert-danger"><?= $error ?></div> <?php endif; ?>
            <?php if($success): ?> <div class="alert alert-success"><?= $success ?></div> <?php endif; ?>
            <form action="forgot_password.php" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nhập Email tài khoản cần khôi phục</label>
                    <input type="email" name="email" class="form-control" required placeholder="email@example.com">
                </div>
                <button type="submit" class="btn btn-danger w-100 py-2 fw-bold">Gửi mật khẩu mới</button>
            </form>
            <div class="text-center mt-3">
                <a href="login.php" class="text-decoration-none">Quay lại trang Đăng nhập</a>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>