<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$role = $_SESSION['role'];

// Xử lý logic Xóa Kỳ Thi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_contest_id'])) {
    if (in_array($role, ['teacher', 'admin'])) {
        $del_id = $_POST['delete_contest_id'];
        $pdo->prepare("DELETE FROM contests WHERE id = ?")->execute([$del_id]);
        echo "<script>alert('Đã xóa kỳ thi thành công!'); window.location='contests.php';</script>";
        exit;
    }
}

$stmt = $pdo->query("SELECT * FROM contests ORDER BY start_time DESC");
$contests = $stmt->fetchAll();
$current_time = date('Y-m-d H:i:s');
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-white">🏆 Các Kỳ Thi Đang Diễn Ra</h2>
    <?php if (in_array($role, ['teacher', 'admin'])): ?>
        <a href="create_contest.php" class="btn btn-warning fw-bold text-dark">+ Thiết lập kỳ thi mới</a>
    <?php endif; ?>
</div>

<div class="row">
    <?php if (count($contests) == 0): ?>
        <div class="col-12 text-center text-white-50 py-5 card">Hiện tại không có kỳ thi lập trình nào.</div>
    <?php else: ?>
        <?php foreach ($contests as $ct): 
            $is_active = ($current_time >= $ct['start_time'] && $current_time <= $ct['end_time']);
            $not_started = ($current_time < $ct['start_time']);
            $ended = ($current_time > $ct['end_time']);
        ?>
            <div class="col-md-6 mb-4">
                <div class="card p-4 h-100 border-start border-4 <?= $is_active ? 'border-success' : ($not_started ? 'border-primary' : 'border-secondary') ?>">
                    <h4 class="fw-bold text-white mb-2"><?= htmlspecialchars($ct['title']) ?></h4>
                    <p class="text-white-50 mb-2 small">
                        🕒 <strong>Bắt đầu:</strong> <?= date('H:i d/m/Y', strtotime($ct['start_time'])) ?><br>
                        🕒 <strong>Kết thúc:</strong> <?= date('H:i d/m/Y', strtotime($ct['end_time'])) ?>
                    </p>
                    
                    <div class="mt-auto pt-3 d-flex justify-content-between align-items-center border-top border-secondary">
                        <div>
                            <?php if ($is_active): ?> <span class="badge bg-success">Đang diễn ra</span>
                            <?php elseif ($not_started): ?> <span class="badge bg-primary">Chưa bắt đầu</span>
                            <?php else: ?> <span class="badge bg-secondary">Đã kết thúc</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <?php if (in_array($role, ['teacher', 'admin'])): ?>
                                <form method="POST" class="d-inline" onsubmit="return confirm('⚠️ CẢNH BÁO: Bạn có chắc chắn muốn xóa kỳ thi này không?\n\nToàn bộ dữ liệu đề bài, điểm số và bài nộp của học sinh trong kỳ thi này sẽ BỊ XÓA VĨNH VIỄN!');">
                                    <input type="hidden" name="delete_contest_id" value="<?= $ct['id'] ?>">
                                    <button type="submit" class="btn btn-outline-danger fw-bold">🗑️ Xóa</button>
                                </form>
                            <?php endif; ?>

                            <?php if ($is_active || $ended || in_array($role, ['teacher', 'admin'])): ?>
                                <a href="contest_view.php?id=<?= $ct['id'] ?>" class="btn <?= $is_active ? 'btn-success' : 'btn-outline-light' ?> fw-bold px-4">Truy cập</a>
                            <?php else: ?>
                                <button class="btn btn-outline-secondary px-4" disabled>Chưa mở</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>