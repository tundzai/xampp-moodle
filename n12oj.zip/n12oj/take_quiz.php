<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$quiz_id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];

// Lấy thông tin Quiz
$stmt = $pdo->prepare("SELECT * FROM quizzes WHERE id = ?"); $stmt->execute([$quiz_id]);
$quiz = $stmt->fetch();
if (!$quiz) die("Không tìm thấy Quiz!");

// Logic 4A: Quản lý Session làm bài (Chống F5)
$stmt = $pdo->prepare("SELECT * FROM quiz_attempts WHERE user_id=? AND quiz_id=? AND status='in_progress'");
$stmt->execute([$user_id, $quiz_id]);
$attempt = $stmt->fetch();

$current_time = time();

if (!$attempt) {
    // Tạo phiên làm bài mới
    $start_time = date('Y-m-d H:i:s', $current_time);
    $end_time = date('Y-m-d H:i:s', $current_time + ($quiz['duration_minutes'] * 60));
    
    // Đếm tổng số câu
    $c_stmt = $pdo->prepare("SELECT COUNT(*) FROM questions WHERE quiz_id=?"); $c_stmt->execute([$quiz_id]);
    $total_q = $c_stmt->fetchColumn();

    $pdo->prepare("INSERT INTO quiz_attempts (user_id, quiz_id, start_time, end_time, total_questions) VALUES (?, ?, ?, ?, ?)")
        ->execute([$user_id, $quiz_id, $start_time, $end_time, $total_q]);
    $attempt_id = $pdo->lastInsertId();
    $time_remaining = $quiz['duration_minutes'] * 60;
} else {
    // Phục hồi phiên làm bài
    $attempt_id = $attempt['id'];
    $end_timestamp = strtotime($attempt['end_time']);
    $time_remaining = $end_timestamp - $current_time;
    
    if ($time_remaining <= 0) {
        // Hết giờ -> Tự động nộp bài
        echo "<script>window.location='submit_quiz.php?attempt_id=$attempt_id';</script>"; exit;
    }
}

// Lấy toàn bộ Câu hỏi và Đáp án
$stmt_q = $pdo->prepare("SELECT * FROM questions WHERE quiz_id = ? ORDER BY id ASC"); $stmt_q->execute([$quiz_id]);
$questions = $stmt_q->fetchAll();

// Lấy danh sách đáp án đã tick dở (Lưu nháp 4A)
$stmt_ans = $pdo->prepare("SELECT question_id, option_id FROM attempt_answers WHERE attempt_id = ?");
$stmt_ans->execute([$attempt_id]);
$draft_answers = [];
while ($row = $stmt_ans->fetch()) {
    $draft_answers[$row['question_id']][] = $row['option_id'];
}
?>
<style>
/* Style ô vuông rỗng bên TRÁI có dấu 'x' khi tích */
.quiz-check-input { appearance: none; width: 22px; height: 22px; border: 2px solid #8a8fab; border-radius: 3px; background: transparent; cursor: pointer; outline: none; margin-right: 12px; position: relative; flex-shrink: 0; }
.quiz-check-input:checked { border-color: #f59e0b; }
.quiz-check-input:checked::after { content: 'x'; position: absolute; color: #f59e0b; font-size: 20px; font-weight: bold; font-family: 'Times New Roman', serif; top: 40%; left: 50%; transform: translate(-50%, -50%); }
.opt-label { cursor: pointer; display: flex; align-items: center; padding: 8px 12px; border-radius: 5px; transition: 0.2s; }
.opt-label:hover { background-color: rgba(255,255,255,0.05); }

/* Sticky Right Panel */
.sticky-panel { position: sticky; top: 20px; }
.timer-box { font-size: 2rem; font-weight: bold; letter-spacing: 2px; text-align: center; font-family: monospace; }
</style>

<div class="row">
    <!-- 70% BÊN TRÁI: Câu hỏi & Đáp án -->
    <div class="col-lg-8 mb-4">
        <h3 class="fw-bold text-warning mb-4"><?= htmlspecialchars($quiz['title']) ?></h3>
        <form id="quizRealForm" action="submit_quiz.php" method="POST">
            <input type="hidden" name="attempt_id" value="<?= $attempt_id ?>">
            
            <?php foreach ($questions as $index => $q): ?>
                <div class="card p-4 mb-4">
                    <h5 class="fw-bold mb-3">Câu <?= $index + 1 ?>: <?= nl2br(htmlspecialchars($q['question_text'])) ?></h5>
                    
                    <?php
                    $stmt_o = $pdo->prepare("SELECT * FROM options WHERE question_id = ? ORDER BY id ASC");
                    $stmt_o->execute([$q['id']]);
                    $options = $stmt_o->fetchAll();
                    foreach ($options as $opt): 
                        // Kiểm tra xem đã tick nháp chưa
                        $is_checked = (isset($draft_answers[$q['id']]) && in_array($opt['id'], $draft_answers[$q['id']])) ? 'checked' : '';
                    ?>
                        <label class="opt-label">
                            <input type="checkbox" name="answers[<?= $q['id'] ?>][]" value="<?= $opt['id'] ?>" class="quiz-check-input ajax-save" data-qid="<?= $q['id'] ?>" <?= $is_checked ?>>
                            <span class="fs-5"><?= htmlspecialchars($opt['option_text']) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </form>
    </div>

    <!-- 30% BÊN PHẢI: Đồng hồ & Nộp bài -->
    <div class="col-lg-4">
        <div class="card p-4 border-warning sticky-panel">
            <h5 class="text-center text-muted mb-2">THỜI GIAN CÒN LẠI</h5>
            <div class="timer-box text-warning mb-4" id="timer">00:00:00</div>
            <button type="button" class="btn btn-success fw-bold py-3 fs-5" onclick="submitQuiz()">NỘP BÀI NGAY</button>
            <p class="text-center small text-muted mt-3">Hệ thống tự động lưu nháp mỗi khi bạn chọn đáp án. Có thể ấn F5 an toàn.</p>
        </div>
    </div>
</div>

<script>
// Logic Đếm ngược & Tự động nộp
let timeRemaining = <?= $time_remaining ?>;
const timerEl = document.getElementById('timer');

function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return (h < 10 ? "0"+h : h) + ":" + (m < 10 ? "0"+m : m) + ":" + (s < 10 ? "0"+s : s);
}

const countdown = setInterval(() => {
    if (timeRemaining <= 0) {
        clearInterval(countdown);
        timerEl.innerText = "HẾT GIỜ!";
        submitQuiz();
    } else {
        timerEl.innerText = formatTime(timeRemaining);
        timeRemaining--;
    }
}, 1000);

function submitQuiz() {
    if(timeRemaining > 0 && !confirm("Bạn có chắc chắn muốn nộp bài sớm không?")) return;
    document.getElementById('quizRealForm').submit();
}

// Logic AJAX Lưu nháp Realtime (Yêu cầu 4A)
document.querySelectorAll('.ajax-save').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        const qId = this.dataset.qid;
        // Lấy tất cả các checkbox đang được tích của câu hỏi này
        const checkedBoxes = document.querySelectorAll(`input[name="answers[${qId}][]"]:checked`);
        const selectedOptIds = Array.from(checkedBoxes).map(cb => cb.value);

        const formData = new FormData();
        formData.append('attempt_id', <?= $attempt_id ?>);
        formData.append('question_id', qId);
        formData.append('option_ids', JSON.stringify(selectedOptIds));

        fetch('save_draft.php', { method: 'POST', body: formData })
        .then(response => response.text())
        .then(data => console.log("Đã lưu nháp câu " + qId));
    });
});
</script>
<?php require_once 'includes/footer.php'; ?>