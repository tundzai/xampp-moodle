<?php
require_once 'includes/header.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$attempt_id = $_GET['attempt_id'] ?? 0;
$stmt = $pdo->prepare("
    SELECT qa.*, q.title 
    FROM quiz_attempts qa 
    JOIN quizzes q ON qa.quiz_id = q.id 
    WHERE qa.id = ? AND qa.user_id = ?
");
$stmt->execute([$attempt_id, $_SESSION['user_id']]);
$attempt = $stmt->fetch();

if (!$attempt) die("Kết quả không tồn tại.");

// Lấy câu hỏi
$stmt_q = $pdo->prepare("SELECT * FROM questions WHERE quiz_id = ?"); 
$stmt_q->execute([$attempt['quiz_id']]);
$questions = $stmt_q->fetchAll();

// Lấy lựa chọn của user
$stmt_ans = $pdo->prepare("SELECT option_id FROM attempt_answers WHERE attempt_id = ?");
$stmt_ans->execute([$attempt_id]);
$user_choices = $stmt_ans->fetchAll(PDO::FETCH_COLUMN);
?>
<style>
/* Tích V xanh và X đỏ theo yêu cầu */
.res-icon { font-weight: bold; font-family: sans-serif; margin-left: 10px; font-size: 1.2rem; }
.icon-correct { color: #10b981; } /* Xanh */
.icon-wrong { color: #ef4444; }   /* Đỏ */
.opt-box { padding: 8px 12px; margin-bottom: 5px; border-radius: 5px; border: 1px solid #232530; background: #16171e; }
.user-selected { border-color: #f59e0b; background: rgba(245, 158, 11, 0.1); }
</style>

<div class="card p-5 mb-4 text-center border-success" style="background-color: #0d1a14;">
    <h1 class="fw-bold text-white mb-2">KẾT QUẢ BÀI LÀM</h1>
    <h3 class="text-muted"><?= htmlspecialchars($attempt['title']) ?></h3>
    <div class="display-3 fw-bold text-success mt-3"><?= $attempt['score'] ?> / <?= $attempt['total_questions'] ?></div>
    <p class="text-white-50 mt-2">Nộp bài lúc: <?= date('d/m/Y H:i:s', strtotime($attempt['submitted_at'])) ?></p>
</div>

<h4 class="fw-bold text-warning mb-4">Chi tiết đáp án:</h4>

<?php foreach ($questions as $index => $q): 
    $stmt_o = $pdo->prepare("SELECT * FROM options WHERE question_id = ? ORDER BY id ASC");
    $stmt_o->execute([$q['id']]);
    $options = $stmt_o->fetchAll();
    
    // Logic 1A: Kiểm tra câu này User đúng hay sai
    $correct_opts = array_column(array_filter($options, fn($o) => $o['is_correct'] == 1), 'id');
    $user_opts_for_q = array_intersect($user_choices, array_column($options, 'id'));
    // Sort array để so sánh == cho chuẩn (phòng khi thứ tự lệch)
    sort($correct_opts); sort($user_opts_for_q);
    $is_q_correct = ($correct_opts == $user_opts_for_q);
?>
    <div class="card p-4 mb-4 <?= $is_q_correct ? 'border-success' : 'border-danger' ?>">
        <h5 class="fw-bold mb-3 text-white">Câu <?= $index + 1 ?>: <?= nl2br(htmlspecialchars($q['question_text'])) ?>
            <span class="float-end res-icon <?= $is_q_correct ? 'icon-correct' : 'icon-wrong' ?>">
                <?= $is_q_correct ? '✔ Chính xác' : '✘ Sai' ?>
            </span>
        </h5>
        
        <?php foreach ($options as $opt): 
            $is_user_checked = in_array($opt['id'], $user_choices);
            $is_real_correct = $opt['is_correct'] == 1;
        ?>
            <div class="opt-box <?= $is_user_checked ? 'user-selected' : '' ?>">
                <span class="text-white-50">[<?= $is_user_checked ? '<strong class="text-warning">x</strong>' : '&nbsp;' ?>]</span> 
                <span class="ms-2 fs-5 text-white"><?= htmlspecialchars($opt['option_text']) ?></span>
                
                <!-- Hiện tick xanh/đỏ ở CỐI ĐÁP ÁN NHƯ YÊU CẦU -->
                <?php if ($is_user_checked): ?>
                    <?php if ($is_real_correct): ?>
                        <span class="float-end res-icon icon-correct">✔</span>
                    <?php else: ?>
                        <span class="float-end res-icon icon-wrong">✘</span>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if ($is_real_correct): ?>
                        <span class="float-end text-success small fw-bold">(Đáp án đúng bị bỏ lỡ)</span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>

<div class="text-center mt-5 mb-5">
    <a href="problems.php" class="btn btn-primary px-5 py-3 fw-bold fs-5 text-dark">Quay về trang chủ</a>
</div>
<?php require_once 'includes/footer.php'; ?>