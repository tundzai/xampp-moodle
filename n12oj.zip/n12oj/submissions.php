<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Tìm toàn bộ lịch sử nộp bài của tài khoản đang đăng nhập
$stmt = $pdo->prepare("
    SELECT s.*, p.title as problem_title 
    FROM submissions s 
    JOIN problems p ON s.problem_id = p.id 
    WHERE s.user_id = ? 
    ORDER BY s.id DESC
");
$stmt->execute([$_SESSION['user_id']]);
$submissions = $stmt->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-white">📋 Lịch Sử Các Bài Nộp Hệ Thống</h2>
</div>

<div class="card p-3 border-0">
    <div class="table-responsive">
        <table class="table table-dark table-hover align-middle mb-0" style="border-color: #232530;">
            <thead style="background-color: #0d0e12;">
                <tr>
                    <th class="py-3 px-3">Mã bài nộp</th>
                    <th class="py-3">Tên bài tập</th>
                    <th class="py-3">Thời điểm nộp</th>
                    <th class="py-3">Trạng thái chấm</th>
                    <th class="py-3">Tỉ số (Testcase)</th>
                    <th class="py-3 text-end px-4">Mã nguồn</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($submissions) == 0): ?>
                    <tr>
                        <td colspan="6" class="text-center text-white-50 py-5">Bạn chưa nộp bất kỳ mã nguồn chấm bài nào.</td>
                    </tr>
                <?php else: ?>
                    <?php $count = count($submissions); foreach ($submissions as $index => $sub): ?>
                        <tr style="border-bottom: 1px solid #232530;">
                            <td class="px-3 text-white-50"><strong>#<?= $sub['id'] ?></strong></td>
                            <td class="fw-bold text-white"><?= htmlspecialchars($sub['problem_title']) ?></td>
                            <td class="text-white-50 small"><?= date('d/m/Y H:i:s', strtotime($sub['created_at'])) ?></td>
                            <td>
                                <?php if($sub['status'] == 'Accepted'): ?>
                                    <span class="badge bg-success">Chấp nhận (AC)</span>
                                <?php elseif($sub['status'] == 'Compile Error'): ?>
                                    <span class="badge bg-danger">Lỗi biên dịch (CE)</span>
                                <?php elseif($sub['status'] == 'Wrong Answer'): ?>
                                    <span class="badge bg-danger">Kết quả sai (WA)</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark"><?= $sub['status'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold text-white-50">
                                <?= $sub['passed_testcases'] ?>/<?= $sub['total_testcases'] ?>
                            </td>
                            <td class="text-end px-4">
                                <!-- Nút Xem/Đóng Code -->
                                <button class="btn btn-sm btn-outline-info fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#code-collapse-<?= $index ?>" aria-expanded="false" onclick="toggleCodeBtn(this)">Xem</button>
                            </td>
                        </tr>
                        
                        <!-- Dòng ẩn chứa Code (Hiển thị mượt mà bằng Collapse) -->
                        <tr class="p-0 border-0 bg-transparent">
                            <td colspan="6" class="p-0 border-0">
                                <div class="collapse w-100" id="code-collapse-<?= $index ?>">
                                    <div class="p-3" style="background-color: #0d0e12; border-bottom: 1px solid #232530;">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="fw-bold text-success small mb-0">Mã nguồn đã nộp:</h6>
                                            <button class="btn btn-sm btn-dark text-white-50 border-secondary py-0" onclick="copyCode('code-block-<?= $index ?>', this)">Copy Code</button>
                                        </div>
                                        <pre class="p-3 rounded text-white" id="code-block-<?= $index ?>" style="background-color: #16171e; border: 1px solid #232530; font-family: monospace; font-size: 0.9rem; overflow-x: auto; white-space: pre-wrap;"><?= htmlspecialchars($sub['code']) ?></pre>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Hàm chuyển đổi nút Xem / Đóng
    function toggleCodeBtn(btn) {
        if (btn.innerText === 'Xem') {
            btn.innerText = 'Đóng';
            btn.classList.replace('btn-outline-info', 'btn-outline-secondary');
        } else {
            btn.innerText = 'Xem';
            btn.classList.replace('btn-outline-secondary', 'btn-outline-info');
        }
    }

    // (Tuỳ chọn) Thêm chức năng Copy nhanh code để user dễ dàng làm lại
    function copyCode(elementId, btn) {
        const codeElement = document.getElementById(elementId);
        const textArea = document.createElement("textarea");
        textArea.value = codeElement.innerText;
        document.body.appendChild(textArea);
        textArea.select();
        try {
            document.execCommand('copy');
            const originalText = btn.innerText;
            btn.innerText = 'Đã Copy!';
            btn.classList.replace('btn-dark', 'btn-success');
            setTimeout(() => {
                btn.innerText = originalText;
                btn.classList.replace('btn-success', 'btn-dark');
            }, 2000);
        } catch (err) {
            console.error('Không thể copy code', err);
        }
        document.body.removeChild(textArea);
    }
</script>

<?php require_once 'includes/footer.php'; ?>